var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
    
    
    async.waterfall([
        commons.getAccessToken.bind(null, tenant_id, client_id, client_secret),
        getWebAppList.bind(null, subscriptionId)
    ], function(err, webApps){
            var requestsForOMS = [];
            for(var webApp of webApps){
                if(commons.shouldIStoreThisResourceInsideMyOMS(webApp.resourceGroup, env)){
                    requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "WebApps", webApp));
                }
            }
            async.parallelLimit(requestsForOMS, 10, function(err, results){
                console.log(results);
                context.done();
            });
    });
    
};

var getWebAppList = function(subscriptionID, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionID+"/providers/Microsoft.Web/sites?api-version=2016-08-01";

    commons.getDataFromMSAPI(accessToken, url, function(err, webApps){
        for(var webApp of webApps){
            var serverFarm = webApp.properties.serverFarmId.substring(webApp.properties.serverFarmId.lastIndexOf("/")+1);
            webApp.properties.serverFarm = serverFarm;
            var subStr = webApp.id.match("resourceGroups/(.*)/providers/");
            webApp.resourceGroup = subStr[1];
        }
        callback(null, webApps);
    }) ;
}