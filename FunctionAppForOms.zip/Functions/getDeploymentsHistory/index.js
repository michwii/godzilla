var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();

    async.waterfall([
        commons.getAccessToken.bind(null, tenant_id, client_id, client_secret),
        getDeploymentsHistory.bind(null, subscriptionId)
    ], function(err, deployments){
        if(err) throw err;

        var requestsForOMS = [];
        for(var deployment of deployments){
            if(commons.shouldIStoreThisResourceInsideMyOMS(deployment.resourceGroup, env) && deployment.length > 0){
              requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "DeploymentsHistory", deployment));
            }
        }

        console.log("Au final " + requestsForOMS.length + "requetes OMS vont être envoyées");
        async.parallelLimit(requestsForOMS, 10, function(err, results){
            console.log(results);
            context.done();
        });


    });
}

var getDeploymentsHistory = function(subscriptionId, accessToken, callback){
  getResourceGroupList(subscriptionId, accessToken, (err, resourceGroups) => {
    if(err) throw err;
    async.mapLimit(resourceGroups, 100, getDeploymentsHistoryByResourceGroup.bind(null, subscriptionId, accessToken), function(err, deploymentstHistory){
      if(err) throw err;
      callback(err, deploymentstHistory);
    });
  });
};

var getResourceGroupList = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+ subscriptionId +"/resourcegroups?api-version=2017-05-10";
    commons.getDataFromMSAPI(accessToken, url, function(err, resourceGroups){
        if(err) throw err;
        callback(err, resourceGroups);
    });
};

var getDeploymentsHistoryByResourceGroup = function(subscriptionId, accessToken, resourceGroup, callback) {
    var url = "https://management.azure.com/subscriptions/" + subscriptionId + "/resourcegroups/" + resourceGroup.name + "/providers/Microsoft.Resources/deployments/?api-version=2018-02-01";
    console.log("Calling getDeploymentsHistoryByResourceGroup for : " + resourceGroup.name);
    commons.getDataFromMSAPI(accessToken, url, (err, deployments) => {
        if(deployments.length === 0){
            console.log("Resource group : " + resourceGroup.name + " is empty");
            callback(err, []);
        }else{
          var yesterdayDate = new Date();
          yesterdayDate.setDate(yesterdayDate.getDate() - 1);
          var yesterdayDeployments = new Array();
          for(var deployment of deployments){
            var subStr = deployment.id.match("resourceGroups/(.*)/providers/");
            deployment.resourceGroup = subStr[1];
            var dateOfDeployment = new Date(deployment.properties.timestamp);
            if(dateOfDeployment.getDate() === yesterdayDate.getDate()){
              yesterdayDeployments.push(deployment);
            }
          }
          console.log("For " + resourceGroup.name + ", " + deployments.length + " deployments total found but only " + yesterdayDeployments.length + " stored with a deployment date of : " + yesterdayDate);
          callback(err, yesterdayDeployments);
        }
    });
};
