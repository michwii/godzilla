var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    
    console.log('Function start')

    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        console.log('JavaScript is running late!');
    }
    commons.getAccessToken(tenant_id, client_id, client_secret, function(err, accessToken){
        console.log('Retrieving token...');
        if(err) throw err;
        getDevTestLabsList(subscriptionId, accessToken, function(err, devTestLabs){
            if(err) throw err;
            console.log('Retrieving Labs...');
            async.mapLimit(devTestLabs, 10, getVirtualMachinesByLab.bind(null, subscriptionId, accessToken), function(err, devTestLabs){
                if(err) throw err;
                console.log('Retrieving VM...');
                var requestsForOMS = [];
                for(var devTestLab of devTestLabs){
                    for(var virtualMachine of devTestLab){
                        if(commons.shouldIStoreThisResourceInsideMyOMS(virtualMachine.resourceGroup, env))
                            requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "VirtualMachinesDevTestLabs", virtualMachine));
                    }
                }
                
                console.log('Send data to OMS...');
                async.parallelLimit(requestsForOMS, 10, function(err, results){
                    context.log(results);
                    context.done();
                })
            });
        });
    });
};
var getDevTestLabsList = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/providers/Microsoft.DevTestLab/labs?api-version=2016-05-15";
    commons.getDataFromMSAPI(accessToken, url, function(err, devTestLabs){
        if(err) throw err;
        for(devTestLab of devTestLabs){
            var subStr = devTestLab.id.match("resourcegroups/(.*)/providers/");
            devTestLab.resourceGroup = subStr[1];
        }
        callback(err, devTestLabs);
    });
};

var getVirtualMachinesByLab = function(subscriptionId, accessToken, devTestLab, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/resourceGroups/"+devTestLab.resourceGroup+"/providers/Microsoft.DevTestLab/labs/"+devTestLab.name+"/virtualmachines?api-version=2016-05-15";
    commons.getDataFromMSAPI(accessToken, url, function(err, virtualMachines){
        if(err) throw err;
        for(var virtualMachine of virtualMachines){
            virtualMachine.devTestLab = devTestLab.name;
            var subStr = virtualMachine.id.match("resourcegroups/(.*)/providers/");
            virtualMachine.resourceGroup = subStr[1];
            console.log('Virtual machine name : ' + virtualMachine.resourceGroup + '\\' + virtualMachine.devTestLab + '\\' + virtualMachine.name + ', ExpirationDate : ' + virtualMachine.properties.expirationDate);
        }
        callback(err, virtualMachines);
    });
};