var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
        
    async.waterfall([
        commons.getAccessToken.bind(null, tenant_id, client_id, client_secret),
        getResourceGroupList.bind(null, subscriptionId)
    ], function(err, resourceGroups){
        if(err) throw err;
        var requestsForOMS = [];
        for(var resourceGroup of resourceGroups){
            if(commons.shouldIStoreThisResourceInsideMyOMS(resourceGroup.name, env))
                requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "ResourceGroups", resourceGroup));

        }
        
        async.parallelLimit(requestsForOMS, 10, function(err, results){
            console.log(results);
            context.done();
        })
    });
}

var getResourceGroupList = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+ subscriptionId +"/resourcegroups?api-version=2017-05-10";
    commons.getDataFromMSAPI(accessToken, url, function(err, resourceGroups){
        if(err) throw err;
        callback(err, resourceGroups);
    });

}
