#Reste à faire V1
46. Gérer les versions mineures/majeures sur la tâches Get Latest repo common => créer un nouveau repo avec un branche master/develop/v2/feature* et un git flow sur la master avec des reviewers obligatoires
23. Mettre en place le git flow / git version sur le répo feature actuel et à venir
52. Pour un environement, gérer plusieurs couloirs : index 01, 02, ... + corridor a, b, c : adapter les noms de webapps (-rea-01), storage de release(reaew1rmcolrsoussa01), sql server (reaafasoussqlaz01ew1)
47. Découpage des repos : un pour l'infra, un pour le SQL, un ou plusieurs pour les sources applicatives
50. Ajouter à la doc : l'ops se crée un repo 'infra', créée une branche develop et la merge avec la master => doc
9. Finaliser la documentation (normer les répertoires de dépôt en sortie de build: des webdeploys, des scripts SQL (Scripts/Release/sql/*release*) )
10. Code review : normes variables, noms des variables, créer un répertoire dédié au main templates, ...
18. Intégrer les ressources V2 (@IP des nouveaux ASE) dans les templates ARM pour filtrage fw sur bdd sql ...
46. Documenter la mécanique globale des templates ARM
49. Faire un tableau des services plan à utiliser par enviornnement (Confluence)

#V2
38. Mise en place de l'audit sur les Azure SQL Database (inclus storage account pour stocker les logs de l'audit)
41. Sizer la bdd à la taille maximum proposée par le pricing tiers utilisé. Par exemple : pour standard S0 à S2, taille bdd (masSize...) à 250 Go

#Backlog
1. Refaire le readme : créer un Kanban 
26. Gestion des services plan en PP/PR
33. Supprimer le storage (à tester) sinon le container courant et les anciens après chaque déploiement
12. Générateur de release (extension VSTS) qui utilise les API VSTS pour générer une release definition projet pour remplacer la release DefaultReleaseDefintion + parameters.json du projet
5. Ajout de la resource Storage Account dans le template ARM
14. Mise en oeuvre de l'intégration continue sur les templates ARM
3. Ajout compte Guy sur le projet VSTS
4. Ajout Redis
34. Automatisation de la création de VM Agent de release VSTS
36. Mise à jour de l'API Version du template AppInsights : impose de préciser le type d'appli (.net, node.js, etc.) + impact sur les charts AppInsights
40. Etudier une solution permettant, en fonction de l'environement, de limiter les pricing tiers utilisables : Standard S0 à S2 par ex.
    => faisable en ARM : si la valeur saisie par le projet est hors de la plage autorisée alors on force un pricing tiers. Ex : si S4 en recette alors on force S2
    => étudier policies Azure
    => ne pas bloquer mais auditer les bdd
42. Nommage des projet / app : voir avec Romain si on est contraints à 4 lettres
43. Synchro des noms VSTS et Azure
44. Sur la tâche 'Deploy project Azure' les projets qui n'ont pas de BDD doivent supprimer du Override template parameters les variables liées à la BDD ; à automatiser via le générateur de la PIC
45. Définir un process pour le développement de nouvelles features (maj templates => maj json de la RD => maj de la RD => etc.)
51. Mettre des rôles de qui fait quoi à l'init d'un projet (arm, release, build, etc) => doc tableau avec actions et acteurs

#Release 20171027
54. Container utilisé sur le container du storage de release projet nécessite minimum 3 caractères : arm-$(Release.ReleaseId)
53. Injecter la "location" dans le nom de sql server
48. Ajouter dans la DefaultReleaseDefinition des tâches webdeploy par défaut
52. Pour un environement, gérer plusieurs couloirs : index 01, 02, ... + corridor a, b, c : adapter les noms de sql server (reaafasoussqlaz01ew1)
39. Changer le pricing tiers par défaut des Azure SQL DB de recette et pprod : passer de basic à standard/S0

#Release 20171011
38. Nom du Azure SQL Server suffixé par l'id du resource group défini au niveau VSTS. Exemple : si Id RG = 02 alors Azure sql server = reafasoussqlaz02

#Release 20171009
37. Suppression de la gestion du Webdeploy dans les templates ARM. A remplacer par des tâches VSTS WebDeploy

#Release 20171009
29. Ajouter les environnements de dev, démo, integ à la custom task Define Resource Group Name
35. Mettre l'output AppInsights aux normes : appinsights:instrumentationKey à changer en APPINSIGHTS_INSTRUMENTATIONKEY

#Release 20171005
6. Evolution de la tâche permettant de récupérer les versions des templates Common pour permettre de choisir la version souhaitée (container)
22. Ajouter les variables sqlbatchpassword et sqluserpassword dans les variables VSTS
24. Récupérer dernière version du blob
25. Gestion de la tâche Webdeploy dans une RD : gérer le cas où on n'a pas de webdeploy dans l'ARM
27. Intégration du SQL Orchestrator (tâche Custom script extension for Windows)
30. maj de la tâche SQL Orchestrator:
    - Exécution des scripts user SQL_ADMIN et non le SQL_SYSADMIN
28. Un seul environnement par défaut dans la DefaultRD et le projet duplique selon ses besoins
31. La RD de référence projet devient la KMA; ancienne à supprimer ou maj

#Release 20170925
20. MAJ version de powershell (5.0) sur les VM de delivery pour le fonctionnement de la tâche ARM Output : gestion des scripts SQL
21. Adaptation de la tâche ARM Output pour qu'elle récupère tous les outputs du déploiement

#Release 20170919
17. Changer l'arborescence Common :
README.md
/Src
/Samples
    /Samples/WebApps with DB
            /main-webapps-sql-#{EnvironmentName-Location}#-parameters.json
            /main-webapps-sql-releaseDefinitionTemplate.json
            /main-webapps-sql-tasksGroup.json
/Docs
19. Mettre en place le git flow / git version sur le répo Common avec gestion des versions majeures & mineures pour les containers qui vont stocker les templates ARM Commmon

#Release 20170915
2.  Sql-template.json : 
- générer les chaines de connexion en securestring pour pas qu'elles apparaissent en clair dans les logs de déploiement du resourceGroup
- gestion d'environnement sur les bdd : basic pour dev, rec, pp / standard pour prod
15. Faire un main chapeau au-dessus des main-webapps-sql.json et main-webapps.json pour déclencher le main adéquat en fonction des paramètres transmis (condition)
16. Gérer le cas WebApps avec SQL + WebApps sans SQL pour un même projet : mettre un object WebAppsSqlToDeploy dans le parameters.json en // du webAppsToDeploy + le webapps-sql.json va chercher les parameters WebAppsSqlToDeploy

#Release 20170913
2.  Sql-template.json : 
- gestion d'environnement sur les @Ips utilisées dans les firewalls
13. Intégrer les ressources V2 (noms ASE) dans les templates ARM pour positionnement webapp
=> nom d'ASE non nécessaire dans le déploiement d'une WebApp. Il est retrouvé automatiquement via le nom du service plan => suppression de la reference à l'ASE dans les templates WebApps, MainTemplates et parameters.json
6. Mise en place du versionning sur le common basé sur une tâche permettant de récupérer les versions des templates Common (container)
=> tâche qui récupère la dernière version du storage (container le plus récent)
9. Documenter les templates ARM : tâches de déploiement, pré-requis, mise en oeuvre VSTS & Json

#Release 20170829
7. Présentation intégration continue sur les templates ARM
=> cf. ppt : utilisation Pester
8. Mise en place de ces templates ARM sur une application test
=> repo "DefaultApplication" dans projet "DevOps" VSTS
=> build definition "workshopARM-ci"
=> release definition "workshopARM-DefaultReleaseDefinition-Webapps-Sql"
11. Gérer en securestring les AppSettings (ou keyvault) pour pas que les mdp apparaissent en clair dans les logs de déploiement du resourceGroup
=> type "SecureObject"
Autres
=> Split main template pour avoir 2 main templates : 1) WebApps + sql 2) WebApps uniquement

TEST LOCK

