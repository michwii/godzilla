#Add dtcollector.exe to PATH variable.
#configure dynatrace collector by updating collector.config

# Enable -Verbose option
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]$ServerDynatrace,
[Parameter(Mandatory=$true)]$PortDynatrace
)

#Add dtcollector.exe to PATH variable.
$DtCollector = "C:\Program Files\Dynatrace\Dynatrace Collector 7.0\"
try
{ 
   $oldPath = [Environment]::GetEnvironmentVariable("PATH","Machine")
   if ($oldPath.Contains($DtCollector) -eq $false){
        Write-Verbose "Set dtcollector.exe to path : $DtCollector" -Verbose
        [Environment]::SetEnvironmentVariable("PATH", $oldPath + ";$DtCollector", "Machine");
    }
    else{
        Write-Verbose "Path Contains already $DtCollector" -Verbose
    }
}
catch
{
   $exceptionText = ($_ | Out-String).Trim()    
   Write-Verbose "Exception occured adding environment variable: $exceptionText in try number $retries" -verbose
   $retries++
   Start-Sleep -Seconds 30 
}

#refresh environment variable
try
{ 
   $env:Path = [System.Environment]::GetEnvironmentVariable("Path","Machine")
}
catch
{
   $exceptionText = ($_ | Out-String).Trim()    
   Write-Verbose "Exception occured refreshing environment variables: $exceptionText in try number $retries" -verbose
   $retries++
   Start-Sleep -Seconds 30 
}

$serviceName = 'Dynatrace Collector 7.0'
If (Get-Service $serviceName -ErrorAction SilentlyContinue) {
    
        
        #Stop service dynatrace collector
        Stop-Service $serviceName
        Write-Host "Stopping $serviceName"

        #Uninstall service dynatrace collector
        dtcollector -service uninstall
        Write-Host "Uninstalling $serviceName"

        #Update collector.config and Start service dynatrace collector
        dtcollector -service install -listen :$PortDynatrace -server $ServerDynatrace 
        
        #Start service dynatrace collector  
        Start-Service $serviceName 
        Write-Host "Starting $serviceName"
}

Else 
{
    Write-Host "$serviceName not found"
}






     


