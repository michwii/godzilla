# Downloads the Visual Studio Team Services Build Agent and installs on the new machine
# and registers with the Visual Studio Team Services account and build agent pool

# Enable -Verbose option
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]$Environment,
[Parameter(Mandatory=$true)]$VSTSAccount,
[Parameter(Mandatory=$true)]$PersonalAccessToken,
[Parameter(Mandatory=$true)]$AgentName,
[Parameter(Mandatory=$true)]$NumberOfAgents
)
 
for ($i=1; $i -le $NumberOfAgents; $i++)
{
    $CurentAgentName =  $AgentName + $Environment +"0"+ $i  
    $CurentAgentServiceName = "vstsagent.$VSTSAccount.$CurentAgentName"
    If (Get-Service $CurentAgentServiceName -ErrorAction SilentlyContinue) 
    {
        $currentLocation = Split-Path -parent $MyInvocation.MyCommand.Definition
        Write-Verbose "Current folder: $currentLocation" -verbose

        $serverUrl = "https://$VSTSAccount.visualstudio.com"
        Write-Verbose "Server URL: $serverUrl" -verbose

        Write-Verbose "Uninstall agent $CurentAgentName" -verbose

        # Construct the agent folder under the main (hardcoded) C: drive.
        $agentInstallationPath = Join-Path "C:" $CurentAgentName

        # Retrieve the path to the config.cmd file.
        $agentConfigPath = [System.IO.Path]::Combine($agentInstallationPath, 'config.cmd')
        Write-Verbose "Agent Location = $agentConfigPath" -Verbose
        if (![System.IO.File]::Exists($agentConfigPath))
        {
            Write-Error "File not found: $agentConfigPath" -Verbose
            return
        }    

        # Set the current directory to the agent dedicated one previously created.
        Push-Location -Path $agentInstallationPath 
		
		.\config.cmd remove --url $serverUrl --token $PersonalAccessToken --unattended

        Pop-Location

        Write-Verbose "Agent uninstall output: $LASTEXITCODE" -Verbose

        Write-Verbose "Exiting UninstallVSTSAgent.ps1" -Verbose
    } 
    Else 
    {
        Write-Host "$CurentAgentServiceName not found" 
    }      
}

