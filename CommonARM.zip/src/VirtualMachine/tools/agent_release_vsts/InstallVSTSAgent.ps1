# Downloads the Visual Studio Team Services Build Agent and installs on the new machine
# and registers with the Visual Studio Team Services account and build agent pool

# Enable -Verbose option
[CmdletBinding()]
Param(
[Parameter(Mandatory=$true)]$Environment,
[Parameter(Mandatory=$true)]$VSTSAccount,
[Parameter(Mandatory=$true)]$PersonalAccessToken,
[Parameter(Mandatory=$true)]$AgentName,
[Parameter(Mandatory=$true)]$PoolName,
[Parameter(Mandatory=$true)]$NumberOfAgents,
[Parameter(Mandatory=$true)]$AgentAccountName,
[Parameter(Mandatory=$true)]$AgentAccountPassword
)


# Set environment variable
Write-Verbose "Set environment variable : azure_env = $Environment" -Verbose
try
{     
   [Environment]::SetEnvironmentVariable("azure_env", $Environment, "Machine")
}
catch
{
   $exceptionText = ($_ | Out-String).Trim()    
   Write-Verbose "Exception occured adding environment variable: $exceptionText in try number $retries" -verbose
   $retries++
   Start-Sleep -Seconds 30 
}

#Add SqlPackage.exe to PATH variable.
$SqlPackagePath = "C:\Program Files (x86)\Microsoft Visual Studio 14.0\Common7\IDE\Extensions\Microsoft\SQLDB\DAC\140\"
try
{ 
   $oldPath = [Environment]::GetEnvironmentVariable("PATH","Machine")
   if ($oldPath.Contains($SqlPackagePath) -eq $false){
        Write-Verbose "Set SqlPackage.exe to path : $SqlPackagePath" -Verbose
        [Environment]::SetEnvironmentVariable("PATH", $oldPath + ";$SqlPackagePath", "Machine");
    }
    else{
        Write-Verbose "Path Contains already $SqlPackagePath" -Verbose
    }
}
catch
{
   $exceptionText = ($_ | Out-String).Trim()    
   Write-Verbose "Exception occured adding environment variable: $exceptionText in try number $retries" -verbose
   $retries++
   Start-Sleep -Seconds 30 
}

#Add azcopy.exe to PATH variable.
$AzCopyPath = "C:\Program Files (x86)\Microsoft SDKs\Azure\AzCopy\"
try
{ 
   $oldPath = [Environment]::GetEnvironmentVariable("PATH","Machine")
   if ($oldPath.Contains($AzCopyPath) -eq $false){
        Write-Verbose "Set AzCopy.exe to path : $AzCopyPath" -Verbose
        [Environment]::SetEnvironmentVariable("PATH", $oldPath + ";$AzCopyPath", "Machine");
    }
    else{
        Write-Verbose "Path Contains already $AzCopyPath" -Verbose
    }
}
catch
{
   $exceptionText = ($_ | Out-String).Trim()    
   Write-Verbose "Exception occured adding environment variable: $exceptionText in try number $retries" -verbose
   $retries++
   Start-Sleep -Seconds 30 
}
       

for ($i=1; $i -le $NumberOfAgents; $i++)
{

    $CurentAgentName =  $AgentName + $Environment +"0"+ $i  
    $CurentAgentServiceName = "vstsagent.$VSTSAccount.$CurentAgentName"
    If (Get-Service $CurentAgentServiceName -ErrorAction SilentlyContinue) 
    {
        If ((Get-Service $CurentAgentServiceName).Status -eq 'Running') 
        {
            Restart-Service -Name $CurentAgentServiceName -force
            Write-Host "Restarting $CurentAgentServiceName"
        } 
        Else 
        {
            Write-Host "$CurentAgentServiceName found, but it is not running."
            Start-Service -Name $CurentAgentServiceName -force
        }
    } 
    Else 
    {
        Write-Host "$CurentAgentServiceName not found"

        Write-Verbose "Entering InstallVSOAgent.ps1" -verbose

        $currentLocation = Split-Path -parent $MyInvocation.MyCommand.Definition
        Write-Verbose "Current folder: $currentLocation" -verbose

        #Create a temporary directory where to download from VSTS the agent package (vsts-agent.zip) and then launch the configuration.
        $agentTempFolderName = Join-Path $env:temp ([System.IO.Path]::GetRandomFileName())
        New-Item -ItemType Directory -Force -Path $agentTempFolderName
        Write-Verbose "Temporary Agent download folder: $agentTempFolderName" -verbose

        $serverUrl = "https://$VSTSAccount.visualstudio.com"
        Write-Verbose "Server URL: $serverUrl" -verbose

        $retryCount = 3
        $retries = 1
        Write-Verbose "Downloading Agent install files" -verbose
        do
        {
          try
          {

            Write-Verbose "Trying to get download URL for latest VSTS agent release..." 
            $user = ""            
            $base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f $user,$PersonalAccessToken)))            
            $latestRelease = Invoke-RestMethod -Uri "$serverUrl/_apis/distributedtask/packages/agent?platform=win-x64" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -ContentType �application/json�            
            $latestReleaseDownloadUrl = $latestRelease.value.downloadUrl | Select-Object -First 1
            Invoke-WebRequest -Uri $latestReleaseDownloadUrl -Method Get -OutFile "$agentTempFolderName\agent.zip" 
            Write-Verbose "Downloaded agent successfully on attempt $retries" -verbose
            break
          }
          catch
          {
            $exceptionText = ($_ | Out-String).Trim()
            Write-Verbose "Exception occured downloading agent: $exceptionText in try number $retries" -verbose
            $retries++
            Start-Sleep -Seconds 30 
          }
        } 
        while ($retries -le $retryCount)


        Write-Verbose "Installation agent $CurentAgentName" -verbose

        # Construct the agent folder under the main (hardcoded) C: drive.
        $agentInstallationPath = Join-Path "C:" $CurentAgentName
        # Create the directory for this agent.
        New-Item -ItemType Directory -Force -Path $agentInstallationPath 

        # Create a folder for the build work
        New-Item -ItemType Directory -Force -Path (Join-Path $agentInstallationPath $WorkFolder)


        Write-Verbose "Extracting the zip file for the agent" -verbose
        $destShellFolder = (new-object -com shell.application).namespace("$agentInstallationPath")
        $destShellFolder.CopyHere((new-object -com shell.application).namespace("$agentTempFolderName\agent.zip").Items(),16)

        # Removing the ZoneIdentifier from files downloaded from the internet so the plugins can be loaded
        # Don't recurse down _work or _diag, those files are not blocked and cause the process to take much longer
        Write-Verbose "Unblocking files" -verbose
        Get-ChildItem -Recurse -Path $agentInstallationPath | Unblock-File | out-null

        # Retrieve the path to the config.cmd file.
        $agentConfigPath = [System.IO.Path]::Combine($agentInstallationPath, 'config.cmd')
        Write-Verbose "Agent Location = $agentConfigPath" -Verbose
        if (![System.IO.File]::Exists($agentConfigPath))
        {
            Write-Error "File not found: $agentConfigPath" -Verbose
            return
        }

        # Call the agent with the configure command and all the options (this creates the settings file) without prompting
        # the user or blocking the cmd execution

        Write-Verbose "Configuring agent" -Verbose

        # Set the current directory to the agent dedicated one previously created.
        Push-Location -Path $agentInstallationPath  

        .\config.cmd --unattended --url $serverUrl --auth PAT --token $PersonalAccessToken --pool $PoolName --agent $CurentAgentName --runasservice --windowslogonaccount $AgentAccountName --windowslogonpassword $AgentAccountPassword

        Pop-Location

        Write-Verbose "Agent install output: $LASTEXITCODE" -Verbose

        Write-Verbose "Exiting InstallVSTSAgent.ps1" -Verbose

    }      

}

