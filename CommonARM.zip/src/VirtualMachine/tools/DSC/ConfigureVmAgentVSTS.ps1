Configuration Main
{

    Param (
        [string] $nodeName
    )

    Import-DscResource -Module PSDesiredStateConfiguration, cChoco, xSystemSecurity, PowerShellModule 

    Node $nodeName
    {        
        cChocoInstaller InstallChoco
        {
	    InstallDir = "c:\choco"
	}        
        
        cChocoPackageInstaller ARMClient
        {
            Name = 'armclient'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
       
	
	PSModuleResource AzureRM
        {
            Module_Name = 'AzureRM'    
            Ensure = 'Present'
			RequiredVersion = '4.4.1'
        }
	
	cChocoPackageInstaller SqlCmd
        {
            Name = 'sqlserver-cmdlineutils'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
	cChocoPackageInstaller SSDT
        {
            Name = 'ssdt15'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
	cChocoPackageInstaller OpenSSL
        {
            Name = 'openssl.light'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
	cChocoPackageInstaller Nuget
        {
            Name = 'nuget.commandline'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller webdeploy
        {
            Name = 'webdeploy'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller azcopy
        {
            Name = 'azcopy'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller azure-cli
        {
            Name = 'azure-cli'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
    }
}