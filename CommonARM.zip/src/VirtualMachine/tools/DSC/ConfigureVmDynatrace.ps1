Configuration Main
{

    Param (
        [string] $nodeName
    )

    Import-DscResource -Module PSDesiredStateConfiguration, cChoco, xSystemSecurity, PowerShellModule 

    Node $nodeName
    {        
        cChocoInstaller InstallChoco
        {
			InstallDir = "c:\choco"
		}   
		cChocoPackageInstaller notepadplusplus
        {
            Name = 'notepadplusplus.install'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true			
        }		
		Package dynatracecollector
        {
            Ensure = 'Present'
            Name = 'Dynatrace Collector 7.0 (x64)'
            Path = 'https://files.dynatrace.com/downloads/OnPrem/dynaTrace/7.0/7.0.0.2469/dynatrace-collector-7.0.0.2469-x86-64.msi' 
			ProductId = '86659A55-7264-43C7-9F93-C12BCC735D55'			
        }       

        
    }
}