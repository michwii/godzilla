Configuration Main
{

    Param (
        [string] $nodeName
    )

    Import-DscResource -Module PSDesiredStateConfiguration, cChoco, xSystemSecurity, PowerShellModule 

    Node $nodeName
    {        
        cChocoInstaller InstallChoco
        {
	    InstallDir = "c:\choco"
	}        
        
        cChocoPackageInstaller ARMClient
        {
            Name = 'armclient'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
       
	
	PSModuleResource AzureRM
        {
            Module_Name = 'AzureRM'    
            Ensure = 'Present'
			RequiredVersion = '4.4.1'
        }
	
	cChocoPackageInstaller SqlCmd
        {
            Name = 'sqlserver-cmdlineutils'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller SSMS
        {
            Name = 'sql-server-management-studio'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
	cChocoPackageInstaller SSDT
        {
            Name = 'ssdt15'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
	
	cChocoPackageInstaller OpenSSL
        {
            Name = 'openssl.light'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
	    AutoUpgrade = $true
        }
	
	cChocoPackageInstaller Nuget
        {
            Name = 'nuget.commandline'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller soapui
        {
            Name = 'soapui'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller notepadplusplus
        {
            Name = 'notepadplusplus.install'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true			
        }
		
	cChocoPackageInstaller curl
        {
            Name = 'curl'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller visualstudiocode
        {
            Name = 'visualstudiocode'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller webdeploy
        {
            Name = 'webdeploy'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller azure-cli
        {
            Name = 'azure-cli'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }
		
	cChocoPackageInstaller googlechrome
        {
            Name = 'googlechrome'
            Ensure = 'Present'
            chocoParams = '--no-progress'
            DependsOn = '[cChocoInstaller]InstallChoco'
			AutoUpgrade = $true
        }

    }
}