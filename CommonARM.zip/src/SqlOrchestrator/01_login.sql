--USE [master]

-- Création du Login DBLoginAdmin s'il n'éxiste pas
IF NOT EXISTS ( SELECT * FROM SYS.SQL_LOGINS WHERE NAME = N'$(DbLoginAdmin)')
BEGIN
	CREATE LOGIN [$(DbLoginAdmin)] WITH PASSWORD=N'$(DbMdpAdmin)'
	Print 'CREATE LOGIN [$(DbLoginAdmin)] WITH PASSWORD=N''$(DbMdpAdmin)''';
END
ELSE
	ALTER LOGIN [$(DbLoginAdmin)] WITH PASSWORD=N'$(DbMdpAdmin)'
	Print 'LOGIN EXISTE DEJA : [$(DbLoginAdmin)] WITH PASSWORD=N''$(DbMdpAdmin)''';
GO

-- Création du Login DbLoginUser s'il n'éxiste pas
IF NOT EXISTS ( SELECT * FROM SYS.SQL_LOGINS WHERE NAME = N'$(DbLoginUser)') 
BEGIN
	CREATE LOGIN [$(DbLoginUser)] WITH PASSWORD=N'$(DbMdpUser)'
	Print 'CREATE LOGIN [$(DbLoginUser)] WITH PASSWORD=N''$(DbMdpUser)''';
END
ELSE
	ALTER LOGIN [$(DbLoginUser)] WITH PASSWORD=N'$(DbMdpUser)'
	Print 'LOGIN EXISTE DEJA : [$(DbLoginUser)] WITH PASSWORD=N''$(DbMdpUser)''';
GO

-- Création du Login DbLoginBatch s'il n'éxiste pas
IF NOT EXISTS ( SELECT * FROM SYS.SQL_LOGINS WHERE NAME = N'$(DbLoginBatch)')
BEGIN
	CREATE LOGIN [$(DbLoginBatch)] WITH PASSWORD=N'$(DbMdpBatch)'
	Print 'CREATE LOGIN [$(DbLoginBatch)] WITH PASSWORD=N''$(DbMdpBatch)''';
END
ELSE
	ALTER LOGIN [$(DbLoginBatch)] WITH PASSWORD=N'$(DbMdpBatch)'
	Print 'LOGIN EXISTE DEJA : [$(DbLoginBatch)] WITH PASSWORD=N''$(DbMdpBatch)''';
GO
 
Print 'AXA-TECH  liste des login/mot de passe' + char(10) + '======================================' + char(10)  + 'Login : $(DbLoginAdmin)    /  Password : $(DbMdpAdmin)' + char(10)  + 'Login : $(DbLoginUser)    /  Password : $(DbMdpUser)' + char(10)  + 'Login : $(DbLoginBatch)    /  Password : $(DbMdpBatch)' + char(10) 
GO