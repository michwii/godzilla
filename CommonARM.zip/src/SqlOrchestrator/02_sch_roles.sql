--USE [BDD]

-- Création le Role DbRole s'il n'éxiste pas
IF NOT EXISTS (SELECT * FROM SYS.DATABASE_PRINCIPALS WHERE NAME = '$(DbRole)')
BEGIN 
	CREATE ROLE [$(DbRole)] AUTHORIZATION [dbo]
	Print 'CREATE ROLE [$(DbRole)] AUTHORIZATION [dbo]';
END
ELSE
	Print 'ROLE EXISTE DEJA: [$(DbRole)] AUTHORIZATION [dbo]';
GO

-- Création du Schema DBSchema s'il n'éxiste pas
IF NOT EXISTS(SELECT * FROM SYS.SCHEMAS WHERE NAME ='$(DbSchema)')
BEGIN
	EXEC sp_executesql N'CREATE SCHEMA [$(DbSchema)] AUTHORIZATION [dbo]'
	Print 'CREATE SCHEMA [$(DbSchema)] AUTHORIZATION [dbo]';
END
ELSE
	Print 'SCHEMA EXISTE DEJA: [$(DbSchema)] AUTHORIZATION [dbo]';
GO

-- Création du User DbLoginAdmin s'il n'éxiste pas
IF NOT EXISTS(SELECT * FROM SYS.SYSUSERS WHERE NAME = '$(DbLoginAdmin)')
BEGIN
	CREATE USER [$(DbLoginAdmin)] FOR LOGIN [$(DbLoginAdmin)] WITH DEFAULT_SCHEMA=[$(DbSchema)]
	Print 'CREATE USER [$(DbLoginAdmin)] FOR LOGIN [$(DbLoginAdmin)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
END
ELSE
	Print 'USER EXISTE DEJA: [$(DbLoginAdmin)] FOR LOGIN [$(DbLoginAdmin)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
GO

-- Création du User DbLoginUser s'il n'éxiste pas
IF NOT EXISTS(SELECT * FROM SYS.SYSUSERS WHERE NAME = '$(DbLoginUser)')
BEGIN
	CREATE USER [$(DbLoginUser)] FOR LOGIN [$(DbLoginUser)] WITH DEFAULT_SCHEMA=[$(DbSchema)]
	Print 'CREATE USER [$(DbLoginUser)] FOR LOGIN [$(DbLoginUser)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
END
ELSE
	Print 'USER EXISTE DEJA: [$(DbLoginUser)] FOR LOGIN [$(DbLoginUser)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
GO

-- Création du User DbLoginBatch s'il n'éxiste pas
IF NOT EXISTS(SELECT * FROM SYS.SYSUSERS WHERE NAME = '$(DbLoginBatch)')
BEGIN
	CREATE USER [$(DbLoginBatch)] FOR LOGIN [$(DbLoginBatch)] WITH DEFAULT_SCHEMA=[$(DbSchema)]
	Print 'CREATE USER [$(DbLoginBatch)] FOR LOGIN [$(DbLoginBatch)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
END
ELSE
	Print 'USER EXISTE DEJA: [$(DbLoginBatch)] FOR LOGIN [$(DbLoginBatch)] WITH DEFAULT_SCHEMA=[$(DbSchema)]';
GO


EXEC sp_addrolemember N'db_ddladmin', N'$(DbLoginAdmin)'
GO
 
PRINT 'sp_addrolemember N''db_ddladmin'', N''$(DbLoginAdmin)''';
GO
 
EXEC sp_addrolemember N'db_securityadmin', N'$(DbLoginAdmin)'
GO
 
PRINT 'sp_addrolemember N''db_securityadmin'', N''$(DbLoginAdmin)''';
GO
 
EXEC sp_addrolemember N'db_datareader', N'$(DbLoginAdmin)'
GO
 
PRINT 'sp_addrolemember N''db_datareader'', N''$(DbLoginAdmin)''';
GO
 
EXEC sp_addrolemember N'db_datawriter', N'$(DbLoginAdmin)'
GO
 
PRINT 'sp_addrolemember N''db_datawriter'', N''$(DbLoginAdmin)''';
GO
 
EXEC sp_addrolemember N'db_datareader', N'$(DbLoginUser)'
GO
 
PRINT 'sp_addrolemember N''db_datareader'', N''$(DbLoginUser)''';
GO
 
EXEC sp_addrolemember N'db_datawriter', N'$(DbLoginUser)'
GO
 
PRINT 'sp_addrolemember N''db_datawriter'', N''$(DbLoginUser)''';
GO
 
EXEC sp_addrolemember N'$(DbRole)', N'$(DbLoginUser)'
GO
 
PRINT 'sp_addrolemember N''$(DbRole)'', N''$(DbLoginUser)''';
GO
 
EXEC sp_addrolemember N'db_datareader', N'$(DbLoginBatch)'
GO
 
PRINT 'sp_addrolemember N''db_datareader'', N''$(DbLoginBatch)''';
GO
 
EXEC sp_addrolemember N'db_datawriter', N'$(DbLoginBatch)'
GO
 
PRINT 'sp_addrolemember N''db_datawriter'', N''$(DbLoginBatch)''';
GO
 
EXEC sp_addrolemember N'$(DbRole)', N'$(DbLoginBatch)'
GO
 
PRINT 'sp_addrolemember N''$(DbRole)'', N''$(DbLoginBatch)''';
GO

ALTER AUTHORIZATION ON SCHEMA::[$(DbSchema)] TO [$(DbLoginAdmin)]
GO
 
PRINT 'ALTER AUTHORIZATION ON SCHEMA::[$(DbSchema)] TO [$(DbLoginAdmin)]';
GO

GRANT EXECUTE TO [$(DbRole)]
GO
 
PRINT 'GRANT EXECUTE TO [N''$(DbRole)'']';
GO