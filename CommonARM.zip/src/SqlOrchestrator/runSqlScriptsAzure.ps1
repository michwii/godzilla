﻿<#
    .SYNOPSIS
        Déploiement automatique de scripts SQL sur base MS SQL Server
    .DESCRIPTION
    .EXAMPLE
        runSqlScripts.ps1
    .NOTES
        FILE NAME  : runSqlScripts.ps1
        AUTHOR     : Yann CRUMEYROLLE, Matthias BLANQUER
        KEYWORDS: SQL, SQL Server
	.History
		Date inconnue :		par Yann CRUMEYROLLE  :	 	Script initial
		Date inconnue :		par Matthias BLANQUER : 	Mise à jour du script pour intégrer le module DevOpsTools (logs)
		2015/09/14 :        par Matthias BLANQUER : 	Mise à jour, la table _ScriptHistory sera dans le schéma dbo
		2015/12/15 :		par Matthias BLANQUER : 	Mise à jour, commande utilisée pour exécuter les scripts (fonction executeScript) : ajout de l'option -x pour prendre en compte les caractères $
		2016/01/18 :		par Matthias BLANQUER : 	Mise à jour de la trace log de la commande effectuée dans l'executeScript pour ne pas afficher le contenu complet du PSObject credentials et donc le mot de passe stocké dans la log
		2016/02/18 :        par Khaled MAHMOUD    :     Adaptation du ps1 pour le jouer dans Azure
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$false)]
    [Alias('server')] 
    [Alias('s')] 
    [string]    
    $serverName="", 
    
    [Parameter(Position=2, Mandatory=$false)]    
    [Alias('d')] 
    [string]    
    $databaseName="", 

    [Parameter(Position=3, Mandatory=$false)]    
    [Alias('u')] 
    [string]    
    $userName="", 

    [Parameter(Position=4, Mandatory=$false)]    
    [Alias('p')] 
    [string]    
    $password="",   

	[Parameter(Position=5, Mandatory=$false)]    
    [Alias('z')] 
    [string]    
    $directorysql="",

    [Parameter(Position=6, Mandatory=$false)]
    [Alias('b')] 
    [string]
    $backupPath=""
) 

#Fonction permettant de récupérer le hash d'un script déjà joué dans la table _ScriptHistory de la bdd
function getPreviousScriptHash($credentials, $filename)
{
    return sqlcmd -S $credentials.ServerName -d $credentials.Database -U $credentials.UserName -P $credentials.Password -Q "SET NOCOUNT ON;select hash from _scriptHistory where Filename='$filename'" -h -1;
}

#Fonction permettant de vérfier si le script a été déjà joué
function checkScriptHash($credentials, $filename)
{

	
    $hash = Get-FileHash "$directorysql\$filename";	
    $previousHash = getPreviousScriptHash $credentials $filename	
    
    if ($previousHash -ne $null)
    {
        if ($previousHash -eq $hash.Hash)
        {
            return $true;
        }
        else
        {
			throw "$filename a été modifié depuis sa dernière exécution"
        }
    }

    return $false;
}

#Fonction permettant de vérfier / créer la table _ScriptHistory de la bdd
function ensureHistoryTableExists($credentials)
{
    $script = "IF OBJECT_ID (N'[dbo].[_ScriptHistory]', N'U') IS NULL CREATE TABLE [dbo].[_ScriptHistory]( [Filename] [nvarchar](1024) NOT NULL, [Hash] [char](64) NOT NULL, [ExecutionDate] [datetime] NOT NULL)";
    	
	Write-Host "Vérification de l'existence de la table ""script history"" en bdd"

	sqlcmd -S $credentials.ServerName -d $credentials.Database -U $credentials.UserName -P $credentials.Password -Q $script -b;
        
    if ($LASTEXITCODE -ne 0) 
    { 
		throw "Erreur lors de la création de la table ""_ScriptHistory"" en bdd"		
    }
    else 
    { 
        Write-Host "Table ""_ScriptHistory"" existante / créée en bdd"        
    }
}

#Fonction permettant de tagger un script dans la table _ScriptHistory de la bdd
function tagScript($credentials, $filename)
{
    $now = Get-Date -Format "yyyy-MM-dd HH:mm:ss.fff"
    $hash = Get-FileHash "$directorysql\$filename"
    $hashValue = $hash.Hash
    Write-Host "Tag du script $filename en base de données pour éviter une exécution future"   	

    $script = "SET NOCOUNT ON;INSERT INTO [_ScriptHistory] (Filename, Hash, ExecutionDate) VALUES ('$filename','$hashValue','$now')"
    sqlcmd -S $credentials.ServerName -d $credentials.Database -U $credentials.UserName -P $credentials.Password -Q $script -b
          
    if ($LASTEXITCODE -ne 0) 
    {
		throw "Erreur lors du tag du script $filename"
    }    
}

#Fonction permettant d'exécuter un script sql
function executeScript($credentials, $filename)
{        
    Write-Host "Exécution du script $filename"
	Write-Host "Command line : sqlcmd -S $($credentials.ServerName) -d $($credentials.Database) -U $($credentials.UserName) -P ****** -i $($filename) -x -b"
	sqlcmd -S $credentials.ServerName -d $credentials.Database -U $credentials.UserName -P $credentials.Password -i "$directorysql\$filename" -x -b
           
    if ($LASTEXITCODE -ne 0) 
    {
		throw "Erreur dans l'exécution du script $filename"
    }    
}

$succeed = 0
$skipped = 0
$total = 0
$databaseBackuped = $false
$credentials = New-Object PSObject -Property @{ ServerName=$serverName; Database=$databaseName; UserName=$userName; Password=$password }

try
{
    
    #Set-Variable -Scope Global -Name _LogDir -Value $outputPath
    $serverName_Temp = $serverName.Replace("\","-")	
	Set-Variable -Scope Global -Name LogPath -Value $LogPath_Temp 
	
	If(!(Test-Path $backupPath))
	{
		New-Item -ItemType Directory -Path $backupPath | Out-Null
	}
	Write-Host "Dossier pour les backups : $backupPath"
	
    ensureHistoryTableExists $credentials 
	
    foreach ($f in Get-ChildItem -path $directorysql -Filter *.sql | sort-object)
    {
        $total++;
        $filename = $f.FullName
		
		$children = Get-ChildItem -path $directorysql
		
		Write-Host "Fichier Sql en cours : $filename"

        $skipScript = checkScriptHash $credentials $f
        if ($skipScript) 
        { 
            $skipped++
            Write-Host "Skip script $f ! Il a été déjà joué"
			continue;
        }      
        
        executeScript $credentials $f 
            
        tagScript $credentials $f
		
        $succeed++
    }
}
catch
{
    # restauration de la base 
    if ($databaseBackuped)
    {
        #restoreDatabase $credentials $backupPath;
    }

    throw;
}
finally
{
    Write-Host "$succeed/$total script(s) exécuté(s)"    
}


