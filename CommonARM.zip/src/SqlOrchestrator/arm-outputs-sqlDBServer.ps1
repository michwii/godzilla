<#------------------------------------------------------------------------------------------
				Powershell
				WEB&DIGITAL 2016
				Khaled MAHMOUD
				AZURE
				Script pour recup�rer les outputs du deploiement "sqlDBServer"  (*.sql)	
				.\arm-outputs-sqlDBServer.ps1 
------------------------------------------------------------------------------------------#>

<#------------------------------------------------------------------------------------------
				Initialisation des variables
------------------------------------------------------------------------------------------#>


param  
(  
	[Parameter(Position=1, Mandatory=$true)]
    [String]
	$resourceGroupName	
)

try
{
	Write-Verbose "Entering script arm-outputs.ps1" 
	Write-Debug "ResourceGroupName= $resourceGroupName"
	$lastResourceGroupDeployment = Get-AzureRmResourceGroupDeployment -ResourceGroupName $resourceGroupName -Name "sqlDBServer" | Sort Timestamp -Descending | Select -First 1 
	$result = $lastResourceGroupDeployment.Outputs.dataBaseInfos.Value.ToString() | ConvertFrom-Json
	if(!$lastResourceGroupDeployment)
	{
		throw "Deployment could not be found for Resource Group '$resourceGroupName'."
	}
	if(!$lastResourceGroupDeployment.Outputs)
	{
		throw "No output parameters could be found for the last deployment of Resource Group '$resourceGroupName'."
	}
	$sqlServerName = $result.sqlServerName
	$sqlDatabaseName = $result.sqlDatabaseName
	$sqlserverSysAdminLogin = $result.sqlserverSysAdminLogin
	
	Write-Host "##vso[task.setvariable variable=sqlServerName;]$sqlServerName"
	Write-Host "##vso[task.setvariable variable=sqlDatabaseName;]$sqlDatabaseName"	
	Write-Host "##vso[task.setvariable variable=sqlserverSysAdminLogin;]$sqlserverSysAdminLogin"
}
catch
{
	Write-Host "arm-outputs-sqlDBServer.ps1" -foregroundcolor red
	Write-Error $_.Exception
}
