﻿<#------------------------------------------------------------------------------------------
				Powershell
				WEB&DIGITAL 2016
				Khaled MAHMOUD
				AZURE
				Script pour injecter des variables dans les sql (*.sql)	
				.\Sql_Orchestrator.ps1 
------------------------------------------------------------------------------------------#>

<#------------------------------------------------------------------------------------------
				Initialisation des variables
------------------------------------------------------------------------------------------#>

param  
(  
	[Parameter(Position=1, Mandatory=$true)]
    [String]
	$serverName,
	
	[Parameter(Position=2, Mandatory=$true)]
    [String]
	$databaseName,
	
	[Parameter(Position=3, Mandatory=$true)]
    [String]
	$sqlUserSysAdmin,	
    
    [Parameter(Position=4, Mandatory=$true)]
    [Security.SecureString]
	$sqlPasswordSysAdmin,
    
    [Parameter(Position=5, Mandatory=$true)]
    [Security.SecureString]
	$sqlPasswordAdmin,
    
    [Parameter(Position=6, Mandatory=$true)]
    [Security.SecureString]
	$sqlPasswordUser,
    
    [Parameter(Position=7, Mandatory=$true)]
    [Security.SecureString]
	$sqlPasswordBatch,    
      
	[Parameter(Position=8, Mandatory=$true)]
    [String]
	$pathsqlmaster,
	
	[Parameter(Position=9, Mandatory=$true)]
    [String]
	$pathsqldatabase,	
	
	[Parameter(Position=10, Mandatory=$true)]
    [String]
	$directorysql,
    
    [Parameter(Position=11, Mandatory=$true)]
    [String]
	$pathsqlapplicatifs
	
)

#Execution sql sur la BDD master
function SqlMaster
{
	Write-Host "Execution script sql sur la base master"
	
	sqlcmd -S $serverName -d "master" -U $sqlUserSysAdmin -P $($CredentialsSysAdmin.GetNetworkCredential().Password) -v DbLoginAdmin = $DBLoginAdmin -v DbMdpAdmin = $($CredentialsAdmin.GetNetworkCredential().Password) -v DbLoginUser = $DBLoginUser -v DbMdpUser = $($CredentialsUser.GetNetworkCredential().Password) -v DbLoginBatch = $DBLoginBatch -v DbMdpBatch = $($CredentialsBatch.GetNetworkCredential().Password) -i $pathsqlmaster 
	
	if ($LASTEXITCODE -ne 0) 
    {        
		throw "Execution script master KO"
    }
    else 
    { 
        Write-Host "Execution script master OK"
    }
	
}

#Execution sql sur la BDD $databaseName
function SqlDataBase
{
	Write-Host "Execution script sql sur la base $databaseName"	
	
	sqlcmd -S $serverName -d $databaseName -U $sqlUserSysAdmin -P $($CredentialsSysAdmin.GetNetworkCredential().Password) -v DbLoginAdmin = $DBLoginAdmin -v DbLoginUser = $DBLoginUser -v DbLoginBatch = $DBLoginBatch -v DbRole = $DBRole -v DbSchema = $DBSchema -i $pathsqldatabase  
		
	if ($LASTEXITCODE -ne 0) 
    {       
		throw "Execution script sqldatabase KO"
    }
    else 
    { 
        Write-Host "Execution script sqldatabase OK"
    }
	
}

try
{
    
	$CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $sqlUserSysAdmin,$sqlPasswordSysAdmin
	
	$script = "SELECT NAME FROM sys.databases";
	
	Write-Host "Connexion BDD..."
	
	#Write-Host "Command line : sqlcmd -S $serverName -d $databaseName -U $sqlUserSysAdmin -P ********"
    Write-Host "Command line : sqlcmd -S $serverName -d $databaseName -U $sqlUserSysAdmin -P $sqlPasswordSysAdmin"
	
	sqlcmd -S $serverName -d $databaseName -U $sqlUserSysAdmin -P $($CredentialsSysAdmin.GetNetworkCredential().Password) -Q $script;    
        
    if ($LASTEXITCODE -ne 0) 
    {  
		throw "Connexion BDD KO"
    }
    else 
    { 
		Write-Host "Connexion BDD OK"
		
		#users applicatifs admin, batch, et user
		$DBSchema = "sch_" + $databaseName
		$DBLoginAdmin = "sql_" + $databaseName + "_admin"
        $DBLoginAdminForSqlCmd = $DBLoginAdmin + "@" + $serverName  
        $CredentialsAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $DBLoginAdmin,$sqlPasswordAdmin        
	
		$DBLoginUser = "sql_" + $databaseName + "_user"
        $CredentialsUser = new-object -typename System.Management.Automation.PSCredential -argumentlist $DBLoginUser,$sqlPasswordUser
		
		$DBLoginBatch = "sql_" + $databaseName + "_batch"        
        $CredentialsBatch = new-object -typename System.Management.Automation.PSCredential -argumentlist $DBLoginBatch,$sqlPasswordBatch
		
		$DBRole = "rol_" + $databaseName + "_exec"
		$DBSchema = "sch_" + $databaseName
		
		#Execution des scripts sur DataBase et master
		SqlMaster		
		SqlDataBase

		# Appel du script sql applicatifs
		try
		{
			Write-Host "Execution des *.sql applicatifs"            
            
			$commandDeploy = '& "'+$pathsqlapplicatifs+'" -serverName "'+$serverName+'" -databaseName "'+$databaseName+'" -userName "'+$DBLoginAdminForSqlCmd+'" -password "'+$($CredentialsAdmin.GetNetworkCredential().Password)+'" -directorysql "'+$directorysql+'" -backupPath ".\SQL\Backup"'            
                        
			Invoke-Expression -Command: $commandDeploy -Verbose
            

		}
		catch
		{
			Write-Host "Echec du PS runSqlScriptsAzure.ps1" -foregroundcolor red
			Write-Error $_.Exception
		}
	
    }	
	
}
catch
{
	Write-Host "Echec du PS SqlOrchestrator.ps1" -foregroundcolor red
	Write-Error $_.Exception
}