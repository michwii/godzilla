<#------------------------------------------------------------------------------------------
				Powershell
				WEB&DIGITAL 2016
				Khaled MAHMOUD
				AZURE
				Script creer ou mettre a jour les nsg
				.\CreateOrUpdateNsg.ps1 
------------------------------------------------------------------------------------------#>

<#------------------------------------------------------------------------------------------
				Initialisation des variables
------------------------------------------------------------------------------------------#>
param  
( 
	[Parameter(Position=1, Mandatory=$true)]
    [String]
	$networkSecurityGroupName,
	
	[Parameter(Position=2, Mandatory=$true)]
    [String]
	$virtualNetworkName,	
    
    [Parameter(Position=3, Mandatory=$true)]
    [String]
	$subnetName,
	
	[Parameter(Position=4, Mandatory=$true)]
    [String]
	$location,

	[Parameter(Position=5, Mandatory=$true)]
    [String]
	$pathcsv
)

Write-Host "Liaison du NSG $networkSecurityGroupName avec le subnet $subnetName"
try
{
	Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityGroupToSubnet -SubnetName $subnetName -VirtualNetworkName $virtualNetworkName -Force
}
catch
{
	Write-Host "Erreur lors de la liaison du NSG $networkSecurityGroupName avec le subnet $subnetName"
	Write-Error $_.Exception
}

Write-Host "Creation ou mise a jour des Inbound security rules pour le nsg $networkSecurityGroupName"
try
{	
	$NSG = Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName
	
	$Rules = Import-Csv $pathcsv
	
	foreach ($Rule in $Rules) 
	{
		try 
		{
			Write-Host "toto3"
			Set-AzureNetworkSecurityRule -Name $Rule.Name `
										 -Type $Rule.Type `
										 -Priority $Rule.Priority `
										 -Action $Rule.Action `
										 -SourceAddressPrefix $Rule.SourceAddressPrefix `
										 -SourcePortRange $Rule.SourcePortRange `
										 -DestinationAddressPrefix $Rule.DestinationAddressPrefix `
										 -DestinationPortRange $Rule.DestinationPortRange `
										 -Protocol $Rule.Protocol `
										 -NetworkSecurityGroup $NSG -ErrorAction Stop | Out-Null
			Write-Host "Created rule $($Rule.Name) successfully"
		} 
		catch 
		{
			Write-Warning "Error creating rule $($Rule.Name)`r`n$_"
			Write-Error $_.Exception
		}
	}
}
catch
{
	Write-Host "Erreur lors de la creation ou mis a jour des Inbound security rules pour le nsg $networkSecurityGroupName"
	Write-Error $_.Exception
}


