# 21/09/2016 : A RETRAVAILLER - ATTENTION les commandes avec "Group xxxx" pour utiliser des Resource Group ne sont pas supportés par MS

$SubscriptionID = "fa63b28e-516b-49c6-af5d-7bdccb3d0410"
$networkSecurityGroupName = "afa-mut-dev-dv-nsg01"
$location = "West Europe"
$virtualNetworkName = "Az-afa-trans-shrd-rec-euw-net01"
$subnetName = "z-afa-trans-shrd-rec-euw-sub04"

# Séléction de la souscription Azure adéquate
Select-AzureSubscription -SubscriptionID $SubscriptionID

# Bascule sur les commandes Powershell Azure V1 pour mettre en place un NSG v1 sur un subnet V1
Switch-AzureMode -Name AzureServiceManagement

# Création d'un Network Security Group
New-AzureNetworkSecurityGroup -Name $networkSecurityGroupName -Location $location

# Association de ce NSG à un subnet
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityGroupToSubnet -SubnetName $SubnetName -VirtualNetworkName $virtualNetworkName

# Création de règles dans ce NSG permettant au subnet d'être accédé uniquement par la Gateway RDP AXA sur le port 3389
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "IN-GTW-RDP1" -Type Inbound -Priority 110 -Action Allow -SourceAddressPrefix '10.208.146.212/32'  -SourcePortRange '*' -DestinationAddressPrefix '*' -DestinationPortRange '3389' -Protocol TCP
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "IN-GTW-RDP2" -Type Inbound -Priority 120 -Action Allow -SourceAddressPrefix '10.208.146.213/32'  -SourcePortRange '*' -DestinationAddressPrefix '*' -DestinationPortRange '3389' -Protocol TCP


# Création de règles dans ce NSG permettant au subnet de contacter les services IOT

Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-PROXY-Port1" -Type Outbound -Priority 130 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix '10.208.28.57/32' -DestinationPortRange '80' -Protocol TCP
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-PROXY-Port2" -Type Outbound -Priority 140 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix '10.208.28.57/32' -DestinationPortRange '8080' -Protocol TCP

# Création de règles dans ce NSG permettant au subnet de contacter les serveurs DNS CoreIT
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-DNS-Serveur1" -Type Outbound -Priority 150 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix '172.20.51.52/32' -DestinationPortRange '53' -Protocol UDP
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-DNS-Serveur2" -Type Outbound -Priority 160 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix '172.20.51.56/32' -DestinationPortRange '53' -Protocol UDP

# Création de règles dans ce NSG permettant au subnet de sortir sur internet en HTTP et HTTPS
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-INTERNET-HTTPS" -Type Outbound -Priority 170 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix 'INTERNET' -DestinationPortRange '443' -Protocol TCP
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-INTERNET-HTTP" -Type Outbound -Priority 180 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix 'INTERNET' -DestinationPortRange '80' -Protocol TCP


# Création de règles dans ce NSG permettant au subnet de contacter les serveurs PASSAXA CoreIT
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "OUT-PASSAXA-HTTPS" -Type Outbound -Priority 190 -Action Allow -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix '172.20.190.58/32' -DestinationPortRange '443' -Protocol TCP


# INTERNET Deny
Get-AzureNetworkSecurityGroup -Name $networkSecurityGroupName | Set-AzureNetworkSecurityRule -Name "DENY-INTERNET" -Type Outbound -Priority 4000 -Action Deny -SourceAddressPrefix '*'  -SourcePortRange '*' -DestinationAddressPrefix 'INTERNET' -DestinationPortRange '*' -Protocol '*'

