# Nécessite la version powershell 0.9.8.1

$SubscriptionId = "fa63b28e-516b-49c6-af5d-7bdccb3d0410" # Souscription DSAT REC
$location = "West Europe"
$networkName = "z-afa-trans-shrd-rec-euw-net01"
$subnetName1 = "z-afa-trans-shrd-rec-euw-sub01"
$subnetName2 = "z-afa-trans-shrd-rec-euw-sub02"
$subnetName3 = "GatewaySubnet"
$subnetName4 = "z-afa-trans-shrd-rec-euw-sub03"
$dnsName1 = "DNSserver1"
$dnsName2 = "DNSserver2"
$localNetworkName ="z-afa-trans-shrd-rec-euw-ln02"
$addressVnet = "10.225.202.0/23"
$addressSubnet1 = "10.225.202.0/26"
$addressSubnet2 = "10.225.202.64/26"
$addressSubnet3 = "10.225.202.128/28"
$addressSubnet4 = "10.225.202.144/28"
$dnsAddress1 = "172.20.51.52"
$dnsAddress2 = "172.20.51.56"
$AddressPrefix = @("172.20.51.56/32","172.20.51.52/32","172.26.210.153/32","10.142.0.0/16","10.208.168.0/24")

try 
{

	# Connexion Azure avec credentials personnels
	Add-AzureAccount
	
	# Séléction de la souscription Azure adéquate
	Select-AzureSubscription -SubscriptionID $SubscriptionID

	# Bascule en mode ARM pour créer le Resource Group et lancer le template ARM
	#Switch-AzureMode -Name AzureResourceManager

	#Chargement des fonctions VNET 
	. .\AzureNetwork-Fonction.ps1
	
	#Récupération de la configuration réseau en cours
	$workingVnetConfig = get-azurenetworkxml
	
	#Creation du VNET SUBNET 
	add-azureVnetNetwork -networkName $networkName -location $location -addressPrefix $addressVnet
	add-azureVnetSubnet -networkName $networkName -subnetName $subnetName1 -addressPrefix $addressSubnet1
	add-azureVnetSubnet -networkName $networkName -subnetName $subnetName2 -addressPrefix $addressSubnet2
	add-azureVnetSubnet -networkName $networkName -subnetName $subnetName3 -addressPrefix $addressSubnet3
	add-azureVnetSubnet -networkName $networkName -subnetName $subnetName4 -addressPrefix $addressSubnet4
	
	#Création DNS 
	add-azureVNetDns -dnsName $dnsName1 -dnsAddress $dnsAddress1
	add-azureVNetDns -dnsName $dnsName2 -dnsAddress $dnsAddress2
	add-azureVnetDnsRef -networkName $networkName -dnsName $dnsName1
	add-azureVnetDnsRef -networkName $networkName -dnsName $dnsName2
	
	#LocalNetwork
	add-azureVnetLocalNetworkSite -networkName $localNetworkName -AddressPrefix $AddressPrefix
	add-azureVnetSiteConnectivity -networkName $networkName -localNetworkName $localNetworkName 
		
	#Set de config
	save-azurenetworkxml($workingVnetConfig)
	
	#Creat GTW
	New-AzureVNetGateway -VNetName $networkName -GatewayType DynamicRouting -GatewaySKU Standard 
}
catch 
{
    Write-Error "/!\ Something went wrong"
    Write-Error $_.Exception
}
