######################################################Get the current Azure Config############################

function get-azureNetworkXml
{
 
$currentVNetConfig = get-AzureVNetConfig
if ($currentVNetConfig -ne $null)
{
[xml]$workingVnetConfig = $currentVNetConfig.XMLConfiguration
} else {
$workingVnetConfig = new-object xml
}
 
$networkConfiguration = $workingVnetConfig.GetElementsByTagName("NetworkConfiguration")
if ($networkConfiguration.count -eq 0)
{
$newNetworkConfiguration = create-newXmlNode -nodeName "NetworkConfiguration"
$newNetworkConfiguration.SetAttribute("xmlns:xsd","http://www.w3.org/2001/XMLSchema")
$newNetworkConfiguration.SetAttribute("xmlns:xsi","http://www.w3.org/2001/XMLSchema-instance")
$networkConfiguration = $workingVnetConfig.AppendChild($newNetworkConfiguration)
}
 
$virtualNetworkConfiguration = $networkConfiguration.GetElementsByTagName("VirtualNetworkConfiguration")
if ($virtualNetworkConfiguration.count -eq 0)
{
$newVirtualNetworkConfiguration = create-newXmlNode -nodeName "VirtualNetworkConfiguration"
$virtualNetworkConfiguration = $networkConfiguration.AppendChild($newVirtualNetworkConfiguration)
}

$dns = $virtualNetworkConfiguration.GetElementsByTagName("Dns")
if ($dns.count -eq 0)
{
$newDns = create-newXmlNode -nodeName "Dns"
$dns = $virtualNetworkConfiguration.AppendChild($newDns)
}

$localNetworks = $virtualNetworkConfiguration.GetElementsByTagName("LocalNetworkSites")
if ($localNetworks.count -eq 0)
{
$newlocalNetworks = create-newXmlNode -nodeName "LocalNetworkSites"
$localNetworks = $virtualNetworkConfiguration.AppendChild($newLocalNetworks)
}

$virtualNetworkSites = $virtualNetworkConfiguration.GetElementsByTagName("VirtualNetworkSites")
if ($virtualNetworkSites.count -eq 0)
{
$newVirtualNetworkSites = create-newXmlNode -nodeName "VirtualNetworkSites"
$virtualNetworkSites = $virtualNetworkConfiguration.AppendChild($newVirtualNetworkSites)
}
 
return $workingVnetConfig
}

####################################Save-azureNetwork XML object################################################

function save-azureNetworkXml($workingVnetConfig)
{
$tempFileName = $env:TEMP + "\azurevnetconfig.netcfg"
$workingVnetConfig.save($tempFileName)
notepad $tempFileName
set-AzureVNetConfig -configurationpath $tempFileName
}

##########################################Add a new Virtual Network##############################################

function add-azureVnetNetwork
{
param
(
[string]$networkName,
[string]$Location,
[string]$addressPrefix
)
 
#check if the network already exists
$networkExists = $workingVnetConfig.GetElementsByTagName("VirtualNetworkSite") | where {$_.name -eq $networkName}
if ($networkExists.Count -ne 0)
{
    write-Output "Network $networkName already exists"
    $newNetwork = $null
    return $newNetwork
}
 
#get the parent node
$workingNode = $workingVnetConfig.GetElementsByTagName("VirtualNetworkSites")
#add the new network node
$newNetwork = create-newXmlNode -nodeName "VirtualNetworkSite"
$newNetwork.SetAttribute("name",$networkName)
$newNetwork.SetAttribute("Location",$Location )
$network = $workingNode.appendchild($newNetwork)
 
#add new address space node
$newAddressSpace = create-newXmlNode -nodeName "AddressSpace"
$AddressSpace = $Network.appendchild($newAddressSpace)
$newAddressPrefix = create-newXmlNode -nodeName "AddressPrefix"
$newAddressPrefix.InnerText=$addressPrefix
$AddressSpace.appendchild($newAddressPrefix)

#return our new network
$newNetwork = $network
return $newNetwork
 
}

#################################################Add a new Subnet###################################################

function add-azureVnetSubnet
{
param
(
[string]$networkName,
[string]$subnetName,
[string]$addressPrefix
)
 
#get our target network
$workingNode = $workingVnetConfig.GetElementsByTagName("VirtualNetworkSite") | where {$_.name -eq $networkName}
if ($workingNode.Count -eq 0)
{
    write-Output "Network $networkName does not exist"
    $newSubnet = $null
    return $newSubnet
}
 
#check if the subnets node exists and if not, create
$subnets = $workingNode.GetElementsByTagName("Subnets")
if ($subnets.count -eq 0)
{
$newSubnets = create-newXmlNode -nodeName "Subnets"
$subnets = $workingNode.appendchild($newSubnets)
}
 
#check to make sure our subnet name doesn't exist and/or prefix isn't already there
$subNetExists = $workingNode.GetElementsByTagName("Subnet") | where {$_.name -eq $subnetName}
if ($subNetExists.count -ne 0)
{
    write-Output "Subnet $subnetName already exists"
    $newSubnet = $null
    return $newSubnet
}
$subNetExists = $workingNode.GetElementsByTagName("Subnet") | where {$_.AddressPrefix -eq $subnetName}
if ($subNetExists.count -ne 0)
{
    write-Output "Address prefix $addressPrefix already exists in another network"
    $newSubnet = $null
    return $newSubnet
}
 
#add the subnet
$newSubnet = create-newXmlNode -nodeName "Subnet"
$newSubnet.SetAttribute("name",$subnetName)
$subnet = $subnets.appendchild($newSubnet)
$newAddressPrefix = create-newXmlNode -nodeName "AddressPrefix"
$newAddressPrefix.InnerText = $addressPrefix
$subnet.appendchild($newAddressPrefix)
 
#return our new subnet
$newSubnet = $subnet
return $newSubnet
}
###################################################Creat a new DnsServer#######################################################
#Add-azureDns net prend deux param�tres: dns Nom et adresse dns pour cr�e ensuite un nouvel �l�ment de dnsserver.
function add-azureVnetDns
{
param
(
[string]$dnsName,
[string]$dnsAddress
)
 
#check that the DNS does not exist
$dnsExists = $workingVnetConfig.GetElementsByTagName("DnsServer") | where {$_.name -eq $dnsName}
if ($dnsExists.Count -ne 0)
{
    write-Output "DNS Server $dnsName already exists"
    $newDns = $null
    return $newDns
}
# get our working node of Dns
$workingNode = $workingVnetConfig.GetElementsByTagName("Dns")
 
#check if the DnsServersRef node exists and if not, create
$dnsServers = $workingNode.GetElementsByTagName("DnsServers")
if ($dnsServers.count -eq 0)
{
$newDnsServers = create-newXmlNode -nodeName "DnsServers"
$dnsServers = $workingNode.appendchild($newDnsServers)
}
 
#add new dns reference
$newDnsServer = create-newXmlNode -nodeName "DnsServer"
$newDnsServer.SetAttribute("name",$dnsName)
$newDnsServer.SetAttribute("IPAddress",$dnsAddress)
$newDns = $dnsServers.appendchild($newDnsServer)
 
#return our new dnsRef
return $newDns
 
}

###################################################add-azurenetDnsRef###############################################
#Add-azur netDns Ref prend deux param�tres; networkName et dNSName. Il check que le r�seau existe et que le DNS existe avant d'ajouter un �l�ment DnsServiceRef pour le DNS au r�seau

function add-azureVnetDnsRef
{
param
(
[string]$networkName,
[string]$dnsName
)
 
#get our target network
$workingNode = $workingVnetConfig.GetElementsByTagName("VirtualNetworkSite") | where {$_.name -eq $networkName}
if ($workingNode.count -eq 0)
{
    write-Output "Network $networkName does not exist"
    $newSubnet = $null
    return $newSubnet
}
 
#check if the DnsServersRef node exists and if not, create
$dnsServersRef = $workingNode.GetElementsByTagName("DnsServersRef")
if ($dnsServersRef.count -eq 0)
{
$newDnsServersRef = create-newXmlNode -nodeName "DnsServersRef"
$dnsServersRef = $workingNode.appendchild($newDnsServersRef)
}
 
#check that the DNS we want to reference is defined already
$dnsExists = $workingVnetConfig.GetElementsByTagName("DnsServer") | where {$_.name -eq $dnsName}
if ($dnsExists.Count -eq 0)
{
    write-Output "DNS Server $dnsName does not exist so cannot be referenced"
    $newDnsRef = $null
    return $newDnsRef
}
 
#check that the dns reference isn't already there
$dnsRefExists = $workingNode.GetElementsByTagName("DnsServerRef") | where {$_.name -eq $dnsName}
if ($dnsRefExists.count -ne 0)
{
    write-Output "DNS reference $dnsName already exists"
    $newDnsRef = $null
    return $newDnsRef
}
 
#add new dns reference
$newDnsServerRef = create-newXmlNode -nodeName "DnsServerRef"
$newDnsServerRef.SetAttribute("name",$dnsName)
$newDnsRef = $dnsServersRef.appendchild($newDnsServerRef)
 
#return our new dnsRef
return $newDnsRef
 
}
#################################################### Add azureVnetLocalNetworkSite#################################################

function add-azureVnetLocalNetworkSite
{
param
(
[string]$networkName,
[Array]$AddressPrefix,
[string]$NombreaddressPrefix
) 

#check if the network already exists
$siteExists = $workingVnetConfig.GetElementsByTagName("LocalNetworkSite") | where {$_.name -eq $networkName}
if ($siteExists.Count -ne 0)
{    
	write-Output "Local Network Site $networkName already exists"
    $newNetwork = $null    
	return $newNetwork
}  
#get the parent node
$workingNode = $workingVnetConfig.GetElementsByTagName("LocalNetworkSites")

#add the new network node
$newNetwork = create-newXmlNode -nodeName "LocalNetworkSite"
$newNetwork.SetAttribute("name",$networkName)
$network = $workingNode.appendchild($newNetwork) 

#add new address space node

$newAddressSpace = create-newXmlNode -nodeName "AddressSpace"
$AddressSpace = $network.appendchild($newAddressSpace)

foreach ($element in $AddressPrefix)
{
$newAddressPrefix = create-newXmlNode -nodeName "AddressPrefix"
$newAddressPrefix.InnerText = $element
$AddressSpace.appendchild($newAddressPrefix)
}



#return our new network
$newNetwork = $network
return $newNetwork 
}

#################################################### Add SiteConnectivity#######################################################
function add-azureVnetSiteConnectivity
{
param
(
[string]$networkName,
[string]$localNetworkName
)

#get our target network
$workingNode = $workingVnetConfig.GetElementsByTagName("VirtualNetworkSite") | where {$_.name -eq $networkName}
if ($workingNode.Count -eq 0)
{
write-Output "Network $networkName does not exist"
$newVnetSiteConnectivity = $null
return $newVnetSiteConnectivity
}	
	
#check that the network has a GatewaySubnet
$subNetExists = $workingNode.GetElementsByTagName("Subnet") | where {$_.name -eq "GatewaySubnet"}
if ($subNetExists.count -eq 0)
{
	write-Output "Virtual network $networkName has no Gateway subnet"
	$newVnetSiteConnectivity = $null
	return $newVnetSiteConnectivity
}
	
#check that the local network site exists
$localNetworkSite = $workingVnetConfig.GetElementsByTagName("LocalNetworkSite") | where {$_.name -eq $localNetworkName}
if ($localNetworkSite.count -eq 0)
{
	write-Output "Local Network Site $localNetworkSite does not exist"
	$newVnetSiteConnectivity = $null
	return $newVnetSiteConnectivity
}
	
#check if the gateway node exists and if not, create
$gateway = $workingNode.GetElementsByTagName("Gateway")
if ($gateway.count -eq 0)
{
$newGateway = create-newXmlNode -nodeName "Gateway"
$gateway = $workingNode.appendchild($newGateway)
} 

#check if the ConnectionsToLocalNetwork node exists and if not, create
$connections = $workingNode.GetElementsByTagName("ConnectionsToLocalNetwork")
if ($connections.count -eq 0)
{
$newConnections = create-newXmlNode -nodeName "ConnectionsToLocalNetwork"
$connections = $gateway.appendchild($newConnections)
} 
	
#check to make sure our local site reference doesn't already exist
$localSiteRefExists = $workingNode.GetElementsByTagName("LocalNetworkSiteRef") | where {$_.name -eq $localNetworkName}
if ($localSiteRefExists.count -ne 0)
{
	write-Output "Local Site Ref $localNetworkName already exists"
	$newVnetSiteConnectivity = $null
    return $newVnetSiteConnectivity
	}
	
#add the local site ref
$newVnetSiteConnectivity = create-newXmlNode -nodeName "LocalNetworkSiteRef"
$newVnetSiteConnectivity.SetAttribute("name",$localNetworkName)
$vNetSiteConnectivity = $connections.appendchild($newVnetSiteConnectivity)
$newConnection = create-newXmlNode -nodeName "Connection"
$newConnection.SetAttribute("type","Dedicated")
$vNetSiteConnectivity.appendchild($newConnection)
	
#return our new subnet
$newVnetSiteConnectivity = $vNetSiteConnectivity
return $newVnetSiteConnectivity
}

###################################################Create a new XML#################################################

function create-newXmlNode
{
param
(
[string]$nodeName
)
 
$newNode = $workingVnetConfig.CreateElement($nodeName,"http://schemas.microsoft.com/ServiceHosting/2011/07/NetworkConfiguration")
return $newNode
}
