<#------------------------------------------------------------------------------------------
				Powershell
				INGENIERIE&AUTOMATION 2018
				Khaled MAHMOUD
				AZURE
				Script pour supprimer tous les containers d'un storage account
				.\DeleteContainers.ps1 
------------------------------------------------------------------------------------------#>

<#------------------------------------------------------------------------------------------
				Initialisation des variables
------------------------------------------------------------------------------------------#>


param  
(  
    [Parameter(Position=1, Mandatory=$true)]
    [String]
	$resourceGroupName,

	[Parameter(Position=2, Mandatory=$true)]
    [String]
	$storageAccountName
)

try
{
	Write-Verbose "Entering script DeleteContainers.ps1"
	$key = (Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName -Name $storageAccountName).Item(0).Value
	$context = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $key
	$containers = Get-AzureStorageContainer -Context $context
	Write-Host "Liste des containers a supprimer : "
	foreach($container in $containers)
	{
		Write-Host $container.Name
	}
	$containers | %{Remove-AzureStorageContainer -Name $_.Name -Context $context -Force}	
    Write-Host "DeleteContainers.ps1 OK" -foregroundcolor green
}
catch
{	
	Write-Host "DeleteContainers.ps1 KO" -foregroundcolor red
	Write-Error $_.Exception
}
