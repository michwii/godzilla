[CmdletBinding()]
Param(
	[Parameter(Mandatory=$True)]
	[string]
	$pfxPath
)


$fileContentBytes = get-content $pfxPath -Encoding Byte

$base64 = [System.Convert]::ToBase64String($fileContentBytes)

Write-Host "##vso[task.setvariable variable=appGatewayPfx;issecret=true;]$base64"