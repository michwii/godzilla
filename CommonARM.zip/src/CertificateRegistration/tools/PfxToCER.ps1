[CmdletBinding()]
Param(
	[Parameter(Mandatory=$False)]
	[string]
	$keyvault_01_Name,
	[Parameter(Mandatory=$False)]
	[string]
	$keyvault_01_frontend_secret

)


Function New-RandomComplexPassword ($length=8)
{
    $Assembly = Add-Type -AssemblyName System.Web
    $password = [System.Web.Security.Membership]::GeneratePassword($length,2)
    return $password
}

$kvSecret = Get-AzureKeyVaultSecret -VaultName "$keyvault_01_Name" -Name "$keyvault_01_frontend_secret"

$kvSecretBytes = [System.Convert]::FromBase64String($kvSecret.SecretValueText) #The PFX itself from KV
$certCollection = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2Collection
$certCollection.Import($kvSecretBytes,$null,[System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable)
$password = New-RandomComplexPassword(100)

$protectedCertificateBytes = $certCollection.Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Pkcs12,$password) #Protected PFX
$certBytes = $certCollection[0].Export([System.Security.Cryptography.X509Certificates.X509ContentType]::Cert) #CER form of cert only


Write-Host "##vso[task.setvariable variable=appGatewayPfx;issecret=true;]$([Convert]::ToBase64String($protectedCertificateBytes))"
Write-Host "##vso[task.setvariable variable=appGatewayPfxPwd;issecret=true;]$password"
Write-Host "##vso[task.setvariable variable=appGatewayCer;issecret=true;]$([Convert]::ToBase64String($certBytes))"