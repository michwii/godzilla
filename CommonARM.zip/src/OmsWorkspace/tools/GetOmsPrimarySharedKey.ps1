<#------------------------------------------------------------------------------------------
				Powershell
				INGENIERIE&AUTOMATION 2018
				Khaled MAHMOUD
				AZURE
				Get PrimarySharedKey from OMS
				.\GetOmsPrimarySharedKey.ps1 
------------------------------------------------------------------------------------------#>

<#------------------------------------------------------------------------------------------
				Initialisation des variables
------------------------------------------------------------------------------------------#>


param  
(  
	[Parameter(Position=1, Mandatory=$true)]
    [String]
	$resourceGroupName,
	
	[Parameter(Position=2, Mandatory=$true)]
    [String]
	$workspaceName
)

try
{
	Write-Verbose "Entering script GetOmsPrimarySharedKey.ps1" 
	Write-Debug "ResourceGroupName= $resourceGroupName"
	Write-Debug "WorkspaceName= $workspaceName"
	$sharedkeys = Get-AzureRmOperationalInsightsWorkspaceSharedKeys -ResourceGroupName $resourceGroupName -Name $workspaceName
	$primarySharedKey = $sharedkeys.PrimarySharedKey
	
	
	Write-Host "##vso[task.setvariable variable=primarySharedKey;]$primarySharedKey"	
}
catch
{
	Write-Host "GetOmsPrimarySharedKey.ps1" -foregroundcolor red
	Write-Error $_.Exception
}
