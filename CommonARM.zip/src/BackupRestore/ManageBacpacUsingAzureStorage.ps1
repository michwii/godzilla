<#
    .SYNOPSIS
        Extract / Import automatique BACPAC depuis BDD Azure et en utilisant un Azure Storage Account
    .DESCRIPTION
    .EXAMPLE
        ManageBacpacUsingAzureStorage.ps1
    .NOTES
        FILE NAME  : ManageBacpacUsingAzureStorage.ps1
        AUTHOR     : Khaled MAHMOUD
        KEYWORDS: SQL, SQL Server, Azure, Azure Storage Account
	.History		
		2017/01/12 :        par Khaled MAHMOUD    :     Initialisation du script
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$true)]
    [string]    
    $serverName="", 
    
    [Parameter(Position=2, Mandatory=$true)]
    [string]    
    $databaseName="", 

    [Parameter(Position=3, Mandatory=$true)] 
    [string]    
    $sqlUserSysAdmin="", 

    [Parameter(Position=4, Mandatory=$true)]
    [Security.SecureString]    
    $sqlPasswordSysAdmin="",
    
    [Parameter(Position=5, Mandatory=$true)]
    [string]    
    $resourceGroupServerName="",
    
    [Parameter(Position=6, Mandatory=$true)]
    [string]    
    $storageUri="",
    
    [Parameter(Position=7, Mandatory=$true)]
    [string]    
    $storageKey="",
	
	[Parameter(Position=8, Mandatory=$false)]
    [string]    
    $edition="",
	
	[Parameter(Position=9, Mandatory=$false)]
    [string]    
    $databaseMaxSizeBytes="",
	
	[Parameter(Position=10, Mandatory=$true)]
    [string]    
    $type=""
) 

try
{
    # Create credentials object from Admin user & password parameters
    $CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $sqlUserSysAdmin,$sqlPasswordSysAdmin    
    
    # Generate a unique filename for the BACPAC
    $bacpacFilename = $databaseName + "-rest-" + (Get-Date).ToString("yyyyMMdd-HHmm") + ".bacpac"    

    # Storage account info for the BACPAC
    $bacpacUri = $storageUri + $bacpacFilename
    $storageKeytype = "StorageAccessKey"    
	
	if ($type -ne "export")
    {
		$exportRequest = New-AzureRmSqlDatabaseExport �ResourceGroupName $resourceGroupServerName �ServerName $serverName -DatabaseName $databaseName �StorageKeytype $storageKeytype �StorageKey $storageKey -StorageUri $bacpacUri -AdministratorLogin $sqlUserSysAdmin �AdministratorLoginPassword $CredentialsSysAdmin.Password
    
		$exportRequest
		
		# Check status of the export
		Get-AzureRmSqlDatabaseImportExportStatus -OperationStatusLink $exportRequest.OperationStatusLink
	}
	
	elseif ($type -ne "import")
	{
		$importRequest = New-AzureRmSqlDatabaseImport �ResourceGroupName $resourceGroupServerName �ServerName $serverName -DatabaseName $databaseName �StorageKeytype $storageKeytype �StorageKey $storageKey -StorageUri $bacpacUri -AdministratorLogin $sqlUserSysAdmin �AdministratorLoginPassword $CredentialsSysAdmin.Password �Edition $edition �ServiceObjectiveName S0 -DatabaseMaxSizeBytes $databaseMaxSizeBytes
    
		$exportRequest
		
		# Check status of the import
		Get-AzureRmSqlDatabaseImportExportStatus -OperationStatusLink $importRequest.OperationStatusLink
	}	
    else
    {
		Write-Host "Le type $type n'existe pas"
		Exit 1
    }  
}
catch
{
	Write-Host "Echec lors de l'execution du sript ExtractBacpac!" -foregroundcolor red
    Write-Error $_.Exception	
}
finally
{
    Write-Host "Fin du script"    
}