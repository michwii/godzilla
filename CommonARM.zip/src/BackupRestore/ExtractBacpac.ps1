<#
    .SYNOPSIS
        Extraction automatique BACPAC depuis BDD Azure
    .DESCRIPTION
    .EXAMPLE
        ExtractBacpac.ps1
    .NOTES
        FILE NAME  : ExtractBacpac.ps1
        AUTHOR     : Khaled MAHMOUD
        KEYWORDS: SQL, SQL Server, AZURE
	.History		
		2016/09/09 :        par Khaled MAHMOUD    :     Initialisation du script
		2016/12/20 :        par Khaled MAHMOUD    :     MAJ du script
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$false)]
    [Alias('server')] 
    [Alias('s')] 
    [string]    
    $sourceServerName="", 
    
    [Parameter(Position=2, Mandatory=$false)]    
    [Alias('d')] 
    [string]    
    $sourceDatabaseName="", 

    [Parameter(Position=3, Mandatory=$false)]    
    [Alias('u')] 
    [string]    
    $sourceSqlUserSysAdmin="", 

    [Parameter(Position=4, Mandatory=$false)]    
    [Alias('p')] 
    [Security.SecureString]    
    $sourceSqlPasswordSysAdmin="",   

	[Parameter(Position=5, Mandatory=$false)]    
    [Alias('z')] 
    [string]    
    $targetPathBacpac=""    
) 

try
{
    $CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $sourceSqlUserSysAdmin,$sourceSqlPasswordSysAdmin
    
	sqlpackage.exe /Action:Export /SourceServerName:$sourceServerName /SourceDatabaseName:$sourceDatabaseName /SourceUser:$sourceSqlUserSysAdmin /SourcePassword:$($CredentialsSysAdmin.GetNetworkCredential().Password) /TargetFile:$targetPathBacpac 
    
    if ($LASTEXITCODE -ne 0) 
    {        
		Write-Host "Extraction KO" -foregroundcolor red
        Exit 1
    }
    else 
    { 
		Write-Host "Extraction OK" -foregroundcolor green
    }
}
catch
{
	Write-Host "Echec lors de l'execution du sript ExtractBacpac!" -foregroundcolor red
    Write-Error $_.Exception	
}