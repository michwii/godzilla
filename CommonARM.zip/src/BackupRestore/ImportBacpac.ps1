<#
    .SYNOPSIS
        Import automatique BACPAC depuis BDD Azure
    .DESCRIPTION
    .EXAMPLE
        ImportBacpac.ps1
    .NOTES
        FILE NAME  : ImportBacpac.ps1
        AUTHOR     : Khaled MAHMOUD
        KEYWORDS: SQL, SQL Server, AZURE
	.History		
		2016/09/09 :        par Khaled MAHMOUD    :     Initialisation du script
		2016/12/20 :        par Khaled MAHMOUD    :     MAJ du script
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$false)]
    [Alias('server')] 
    [Alias('s')] 
    [string]    
    $targetServerName="", 
    
    [Parameter(Position=2, Mandatory=$false)]    
    [Alias('d')] 
    [string]    
    $targetDatabaseName="", 

    [Parameter(Position=3, Mandatory=$false)]    
    [Alias('u')] 
    [string]    
    $targetSqlUserSysAdmin="", 

    [Parameter(Position=4, Mandatory=$false)]    
    [Alias('p')] 
    [Security.SecureString]    
    $targetSqlPasswordSysAdmin="",   

	[Parameter(Position=5, Mandatory=$false)]    
    [Alias('z')] 
    [string]    
    $sourcePathBacpac=""    
) 

try
{
    $CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $targetSqlUserSysAdmin,$targetSqlPasswordSysAdmin
    
	sqlpackage.exe /Action:Import /TargetServerName:$targetServerName /TargetDatabaseName:$targetDatabaseName /TargetUser:$targetSqlUserSysAdmin /TargetPassword:$($CredentialsSysAdmin.GetNetworkCredential().Password) /SourceFile:$sourcePathBacpac 
    
    if ($LASTEXITCODE -ne 0) 
    {        
		Write-Host "Import KO" -foregroundcolor red
        Exit 1
    }
    else 
    { 
		Write-Host "Import OK" -foregroundcolor green
    }
}
catch
{
	Write-Host "Echec lors de l'execution du sript ImportBacpac!" -foregroundcolor red
    Write-Error $_.Exception	
}