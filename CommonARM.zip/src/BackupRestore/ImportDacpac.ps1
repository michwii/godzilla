<#
    .SYNOPSIS
        Import automatique DACPAC avec data depuis BDD Azure
    .DESCRIPTION
    .EXAMPLE
        ImportBacpac.ps1
    .NOTES
        FILE NAME  : ImportBacpac.ps1
        AUTHOR     : Sofiane Yahiaoui
        KEYWORDS: SQL, SQL Server, AZURE, Dacpac
	.History		
		2016/09/09 :        par Sofiane Yahiaoui    :     Initialisation du script
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$false)]
    [Alias('server')] 
    [Alias('s')] 
    [string]    
    $targetServerName="", 
    
    [Parameter(Position=2, Mandatory=$false)]    
    [Alias('d')] 
    [string]    
    $targetDatabaseName="", 

    [Parameter(Position=3, Mandatory=$false)]    
    [Alias('u')] 
    [string]    
    $targetSqlUserSysAdmin="", 

    [Parameter(Position=4, Mandatory=$false)]    
    [Alias('p')] 
    [Security.SecureString]    
    $targetSqlPasswordSysAdmin="",   

	[Parameter(Position=5, Mandatory=$false)]    
    [Alias('z')] 
    [string]    
    $sourcePathBacpac="",
	
	[Parameter(Position=6, Mandatory=$false)]    
    [Alias('r')] 
    [string]    
    $rgName="",

	[Parameter(Position=7, Mandatory=$false)]    
    [Alias('sa')] 
    [string]    
    $storageAccountName="",

	[Parameter(Position=8, Mandatory=$false)]    
    [Alias('c')] 
    [string]    
    $containerName="",
    
    [Parameter(Position=9, Mandatory=$false)]    
    [Alias('e')] 
    [string]    
    $ExcludeObjectTypes="" 
) 

try
{
	#Set Storage Context
	$StorageAccountKey = (Get-AzureRmStorageAccountKey -Name $storageAccountName -ResourceGroupName $rgName)[0].Value
	$StorageContext = New-AzureStorageContext -StorageAccountName $storageAccountName -StorageAccountKey $StorageAccountKey
	$FileName = "$targetDatabaseName.dacpac"

	$blob = Get-AzureStorageBlob -Blob $FileName -Container $containerName -Context $StorageContext -ErrorAction Ignore
	if ($blob)
	{
		Write-Host "Blob Found"
		Get-AzureStorageBlobContent -Container $containerName -Blob $FileName -Destination $sourcePathBacpac -Context $StorageContext -Force
		Write-Host "file copy is done" -foregroundcolor red
	}
	
	$dacpacexist = [System.IO.File]::Exists($sourcePathBacpac)
	if ($dacpacexist -eq "True")
	{
        $CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $targetSqlUserSysAdmin,$targetSqlPasswordSysAdmin
        if ($ExcludeObjectTypes -eq "")
        {
            sqlpackage.exe /action:Publish /TargetServerName:$targetServerName.database.windows.net /TargetDatabaseName:$targetDatabaseName /TargetUser:$targetSqlUserSysAdmin /TargetPassword:$($CredentialsSysAdmin.GetNetworkCredential().Password) /SourceFile:$sourcePathBacpac
        }
        else {
            sqlpackage.exe /action:Publish /TargetServerName:$targetServerName.database.windows.net /TargetDatabaseName:$targetDatabaseName /TargetUser:$targetSqlUserSysAdmin /TargetPassword:$($CredentialsSysAdmin.GetNetworkCredential().Password) /SourceFile:$sourcePathBacpac /Properties:ExcludeObjectTypes=$ExcludeObjectTypes
        }
	}
	else
	{
		Write-Host "dacpac file doesn't exist" -foregroundcolor red
	}
	
    if ($LASTEXITCODE -ne 0) 
    {        
		Write-Host "Import KO" -foregroundcolor red
        Exit 1
    }
    else 
    { 
		Write-Host "Import OK" -foregroundcolor green
    }
}
catch
{
	Write-Host "Echec lors de l'execution du sript ImportBacpac!" -foregroundcolor red
    Write-Error $_.Exception	
}