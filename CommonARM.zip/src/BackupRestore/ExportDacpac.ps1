<#
    .SYNOPSIS
        Export automatique DACPAC avec data depuis BDD Azure
    .DESCRIPTION
    .EXAMPLE
        ExportDacpac.ps1
    .NOTES
        FILE NAME  : ExportDacpac.ps1
        AUTHOR     : Sofiane Yahiaoui
        KEYWORDS: SQL, SQL Server, AZURE , Dacpac
	.History		
		2016/09/09 :        par Sofiane Yahiaoui    :     Initialisation du script
    #Requires -Version 4.0 
#>

param  
(  
    [Parameter(Position=1, Mandatory=$false)]
    [Alias('server')] 
    [Alias('s')] 
    [string]    
    $sourceServerName="", 
    
    [Parameter(Position=2, Mandatory=$false)]    
    [Alias('d')] 
    [string]    
    $sourceDatabaseName="", 

    [Parameter(Position=3, Mandatory=$false)]    
    [Alias('u')] 
    [string]    
    $sourceSqlUserSysAdmin="", 

    [Parameter(Position=4, Mandatory=$false)]    
    [Alias('p')] 
    [Security.SecureString]    
    $sourceSqlPasswordSysAdmin="",   

	[Parameter(Position=5, Mandatory=$false)]    
    [Alias('z')] 
    [string]    
    $targetPathBacpac=""    
) 

try
{
    $CredentialsSysAdmin = new-object -typename System.Management.Automation.PSCredential -argumentlist $sourceSqlUserSysAdmin,$sourceSqlPasswordSysAdmin
	SqlPackage.exe /action:Extract /SourceServerName:$sourceServerName.database.windows.net /SourceDatabaseName:$sourceDatabaseName /SourceUser:$sourceSqlUserSysAdmin /SourcePassword:$($CredentialsSysAdmin.GetNetworkCredential().Password) /TargetFile:$targetPathBacpac /Properties:ExtractAllTableData=True
    
    if ($LASTEXITCODE -ne 0) 
    {        
		Write-Host "Export KO" -foregroundcolor red
        Exit 1
    }
    else 
    { 
		Write-Host "Export OK" -foregroundcolor green
    }
}
catch
{
	Write-Host "Echec lors de l'execution du sript ImportBacpac!" -foregroundcolor red
    Write-Error $_.Exception	
}