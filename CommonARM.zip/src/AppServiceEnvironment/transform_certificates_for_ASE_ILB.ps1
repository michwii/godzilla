﻿param  
(  
    [Parameter(Position=1, Mandatory=$true)]
    [string]
    $ASEId,

	[Parameter(Position=2, Mandatory=$true)]
    [string]
    $PfxDir,

    [Parameter(Position=3, Mandatory=$true)]
    [string]
    $PfxPassword,

    [Parameter(Position=4, Mandatory=$true)]
    [string]
    $PemDir
)

try
{
    # Recherche d'un fichier .pfx dans le répertoire fourni en paramètre $PfxDir
    $PfxFile = Get-ChildItem -Path $PfxDir -Filter "*.pfx"
    $PfxPath = $PfxFile.FullName

    # Test pour savoir si le répertoire transform existe dans le répertoire $PfxDir fourni en paramètre. Si ko alors création du répertoire
    If(!(Test-Path "$PfxDir\transform"))
    {
        New-Item -ItemType directory -Path "$PfxDir\transform" | Out-Null
    }

    # Valorisation des variables KeyPath et PfxOutPath qui serviront à la création (par openssl) de deux fichiers utilisées pour créer le certificat au format accepté par l'ASE et incluant la chaine de certification AXA
    $KeyPath = $PfxDir + "\transform\" + ([string]$PfxFile).Replace('.pfx','-encrypted.key')
    $PfxOutPath = $PfxDir + "\transform\" + ([string]$PfxFile).Replace('.pfx','-toInstall.pfx')
    
    # Recherche d'un fichier .pem.cer et .chain.pem dans le répertoire fourni en paramètre $PemDir
    # Ces fichiers sont fournis dans le zip délivré par la PKI AXA et sont utilisés dans la création du certificat au format accepté par l'ASE et incluant la chaine de certification AXA
    $PemCerPath = (Get-ChildItem -Path $PemDir -Filter "*.pem.cer").FullName
    $ChainPemPath = (Get-ChildItem -Path $PemDir -Filter "*.chain.pem").FullName

    # Passage en string du securestring fourni en paramètre $PfxPassword
    #$BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($PfxPassword)
    #$PfxPasswordUnSecure = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)

    # Récupération (fichier ...-encrypted.key) de la private key du fichier .pfx utilisé pour la demande de certificat à la PKI d'AXA
    Write-Host "[INFO] Get Private Key from .pfx" -ForegroundColor Cyan
    Invoke-Expression "openssl pkcs12 -in $PfxPath -nocerts -out $KeyPath -passin pass:$PfxPassword -passout pass:$PfxPassword" 2>&1

    # Création du certificat (fichier ...-toInstall.pfx) au format attendu par l'ASE. Certificat qui inclus la chaine de certification AXA
    Write-Host "[INFO] Set PFX file including AXA certification path certificates & private key" -ForegroundColor Cyan
    Invoke-Expression "openssl pkcs12 -export -out $PfxOutPath -inkey $KeyPath -in $PemCerPath -certfile $ChainPemPath -passin pass:$PfxPassword -passout pass:$PfxPassword" 2>&1

    # A partir du certificat créé, récupération de sa signature (Thumbprint), récupération du certificat au format base64
    $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2
    $cert.Import("$PfxOutPath","$PfxPassword","DefaultKeySet")
    $Thumbprint = $cert.Thumbprint
    If($Thumbprint -ne "")
    {
        Write-Host "[INFO] Get certificate thumbprint : OK" -ForegroundColor Cyan
    }
    $file = Get-Content -Encoding byte $PfxOutPath
    $fileEncoded = [System.Convert]::ToBase64String($file)
    If($Thumbprint -ne "")
    {
        Write-Host "[INFO] Get certificate base64 : OK" -ForegroundColor Cyan
    }

    # Mise en place de variables VSTS pour permettre de les envoyer en tant que paramètres au template ARM json ASE
    Write-Host "##vso[task.setvariable variable=ENV_$($ASEId)_CertificateThumbprint;]$Thumbprint"
    Write-Host "##vso[task.setvariable variable=ENV_$($ASEId)_CertificatePassword;]$PfxPassword"	
    Write-Host "##vso[task.setvariable variable=ENV_$($ASEId)_CertificatePfxBlobString;]$fileEncoded"
}
catch
{
	Write-Host "transform_certificates_for_ASE_ILB.ps1" -foregroundcolor red
	Write-Error $_.Exception
}