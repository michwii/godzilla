#######################################
# Récupération du SDK et Helpers VSTS #
#######################################

git clone https://github.com/Microsoft/vsts-tasks.git ./Common/vsts-tasks
Save-Module -Name VstsTaskSdk -Path ./Common

#######################################
#     Déploiement dans les tâches     #
#######################################

$dir = dir tasks/* | ? {$_.PSISContainer}

foreach ($d in $dir) {
    If (Test-Path $d/ps_modules) {
        Remove-Item -Path $d/ps_modules -recurse -Force
    }
    
    Copy-Item -Path ./Common/vsts-tasks/Tasks/Common/VstsAzureHelpers_ -Destination $d/ps_modules/VstsAzureHelpers_ -recurse -Force
    Copy-Item -Path ./Common/vsts-tasks/Tasks/Common/TlsHelper_ -Destination $d/ps_modules/TlsHelper_ -recurse -Force
    Copy-Item -Path ./Common/VstsTaskSdk/0.11.0 -Destination $d/ps_modules/VstsTaskSdk -recurse -Force
}

#######################################
#          Remove PS_MODULES          #
#######################################

Remove-Item -Recurse -Force ./Common/