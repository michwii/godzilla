# This script get all stage reach to the clean UP stage
# For these stage, we gonna get back the resource group to delete some resources
# Input : ID clean release ; Name clean relese ; list env
#
# Output : Projet definition ID ; ID Env Def 
#
# Exemple : https://axafrance.vsrm.visualstudio.com/SelfCare/_apis/Release/deployments?definitionId=18&definitionEnvironmentId=55&deploymentStatus=30&operationStatus=7960&%24top=1
#
# Arguments sample : $PAT 14 "test clean env ARD - DailyClean" "Ops.IA" "Clean-RECETTE-EW1" $test

#######################
###### Arguments ######
#######################

param  
(
    [string] $pat,
    [string] $id_def_clean,
    [string] $name_def_clean,
    [string] $project,
    [string] $clean_env,
    [string] $test
)

#######################
###### Variables ######
#######################

$version_api="5.1-preview"
$organization = "axafrance"
$url_api = "https://vsrm.dev.azure.com/$organization/$project/_apis"
$name_def_project = $name_def_clean.replace(" - DailyClean", "")
$result = @{}
$proj_env = $clean_env.replace("Clean-", "")

#################
### Functions ###
#################

function check_needy_clean
{
    param([string]$r, [string]$e)
    $url = "$url_api/release/definitions/$($r)?api-version=$version_api"
    $result = call_url($url)
    foreach($env in $result.environments)
    {
        if ($env.name -like $e)
        {
            foreach ($conditions in $env.conditions)
            {
                if ($conditions.conditionType -like "environmentState")
                {
                    return [bool]$true
                    break
                }
            }
        }
    }
    return [bool]$False
}

function call_url
{
    param([string]$u)
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "pat", $pat)))  
    try {
        $result = (Invoke-RestMethod `
        -Uri $u `
        -Method Get `
        -ContentType "application/json" `
        -Headers @{Authorization = ("Basic {0}" -f $auth)} `
        -UseBasicParsing)
        return $result
    }
    catch {
        Write-error "Call url: " $u
        Write-error "StatusCode for : " $_.Exception.Response.StatusCode.Value__
        Write-error "StatusDescription : " $_.Exception.Response.StatusDescription
        exit 1
    }
}

function get_release_info
{
    param([string]$r,[string]$e)
    $url = "$url_api/release/definitions?searchText=$($r)&isExactNameMatch=true&`$expand=environments&api-version=$version_api"
    $releasedefs_project = call_url($url)
    $result = $releasedefs_project.value | Select-object -First 1
    $id_release_project = $result.id
    $id_env_project = $result.environments | where-object {$_.name -eq "$e"} | select-object -Property id
    $id_release_project
    $id_env_project.id
}

function get_resource_group
{
    param([int32]$r,[int32]$e)
    
    #Variables
    $url = "$url_api/release/definitions/$($r)?api-version=$version_api"
    $result = call_url($url)
    $definition_info = $result.environments | where-object {$_.id -eq $($e)} | Select-Object variables, deployPhases
    $task = $definition_info | Select-Object -ExpandProperty deployPhases | Select-Object -First 1 | where-object {$_.phaseType -eq "agentBasedDeployment"} | select-object -Property workflowTasks

    #Test if task Azure Tagging is available in release workflow
    $rg = $task.workflowTasks | Where-Object {($_.name -match "apply Axa mandatory tags to Azure resource group" )} |Select-Object -Property inputs
    $rg = $rg.inputs.ResourceGroupName

    #If not Azure Tagging available --> go to find ARD Inputs
    if ($rg -eq $null)
    {
        $ard = $task.workflowTasks | Where-Object {$_.name -match "Deploy Azure resources" -and $_.enabled} | Select-Object -ExpandProperty inputs
        
        #Get all variables
        $env_variables += $($definition_info | Select-Object -ExpandProperty variables)
        $release_variables += $result.variables
        $all_var += @($release_variables)
        $all_var += @($env_variables)

        #Check if some variables in ARD inputs ($result)
        foreach ($object_result in $ard.PSObject.Properties)
        {
            if ($object_result.Value -match "^\$" -and $object_result.Name -notmatch "ParametersPath")
            {   
                $var = $object_result.Value.TrimStart("$\(").TrimEnd(")")
                $object_result.Value = $($all_var | Where-Object { $_ -match $var } ).$var.value
                $ard.$($object_result.Name) = $object_result.Value
            }
        }
        $rg = "z-afa-$($ard.ProjectName)-$($ard.AppName)-$($ard.Environment.ToLower())$($ard.Corridor)-ew1-rgp$($ard.ResourceGroupId)"
    }
    $rg
}

function delete_object
{
    param($p, [string]$e)
    try {
        if( $test -match "false")
        {
            Remove-AzureRmResource -ResourceId $($p.ResourceId) -Force
        }
        write-host "==> $($p.Name) ($($p.ResourceType)) is delete " -ForegroundColor green
    }
    catch {
        Write-host "==> ERROR : Cannot remove $($p.Name) ($($p.ResourceType)) for $e" -ForegroundColor Red
    }
}


#######################
######    Main   ######
#######################
Write-Host "-----------------------------------------"
Write-Host "---             Variables             ---"
Write-Host "-----------------------------------------"
Write-host "-- Id_def_clean : $id_def_clean"
Write-host "-- Name_def_clean : $name_def_clean"
Write-host "-- Env_to_clean : $proj_env"
Write-host "-- Env_name : $clean_env"
Write-host "-- Dry-run : $test"
Write-Host "-----------------------------------------"
Write-Host "-----------------------------------------"

## Get back the env link with the clean stage
$envs_to_clean = check_needy_clean $id_def_clean $clean_env

if( $test -match "true")
{
    write-host "#############################################################"
    write-host "-- Dry Run mode start -> the resources will not be deleted --"
    write-host "#############################################################"
}
## Check if needy to clean, info from release definintion
if ($envs_to_clean)
{
    Write-Host "Start cleaning for $($proj_env)"
    $release_info = get_release_info $name_def_project $proj_env
    $resource_groupname = get_resource_group $release_info[0] $release_info[1]
    Write-Host "==> ResourceGroupName : $($resource_groupname)"
    foreach ($pattern in $(Get-AzureRmResource -ResourceGroupName $resource_groupname))
    {
        if ($pattern.ResourceType -match "microsoft.insights" -or $pattern.ResourceType -match "Microsoft.Storage/storageAccounts" -or $pattern.ResourceType -match "Microsoft.Sql" -or $pattern.ResourceId -match "Microsoft.DocumentDB" -or $pattern.ResourceId -match "batch")
        {
            write-host "==> $($pattern.Name) ($($pattern.ResourceType)) will not be delete " -ForegroundColor yellow
        }
        else {
            delete_object $($pattern) $($clean_env)
        }
    }

    ## Case PP : If stage's PP => delete secondary
    if ($resource_groupname -match "-pp[abc]-")
    {
        $second_resource_groupname = $resource_groupname.replace("-ew1-","-en1-")
        write-host "==> #######################################################################"
        write-host "==> Staging environment found, we gonna delete the secondary resourcegroup"
        write-host "==> Secondary ResourceGroupName : $second_resource_groupname"
        foreach ($pattern in $(Get-AzureRmResource -ResourceGroupName $second_resource_groupname))
        {
            if ($pattern.ResourceType -match "microsoft.insights" -or $pattern.ResourceType -match "Microsoft.Storage/storageAccounts" -or $pattern.ResourceType -match "Microsoft.Sql" -or $pattern.ResourceId -match "Microsoft.DocumentDB" -or $pattern.ResourceId -match "batch")
            {
                write-host "==> $($pattern.Name) ($($pattern.ResourceType)) will not be delete " -ForegroundColor yellow
            }
            else {
                delete_object $($pattern) $($clean_env)
            }
        }
    }
    
    #if dryrun, exit with error and message 
    if( $test -match "true")
    {
        
        write-host "########################################################"
        write-host "-- Dry Run mode stop -> the resources has not deleted --"
        write-host "########################################################"
    }
}
else
{
    Write-Host "The environment $($proj_env) doesn't need dailyclean"
}