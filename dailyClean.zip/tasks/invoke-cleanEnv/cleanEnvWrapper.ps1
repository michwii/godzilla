[CmdletBinding(DefaultParameterSetName = 'None')]
param()

$pat = $Env:SYSTEM_ACCESSTOKEN
$id_def_clean = $Env:Release_DefinitionId
$name_def_clean = $Env:Release_DefinitionName
$project = $Env:System_TeamProject
$clean_env = $Env:Release_EnvironmentName
$test = Get-VstsInput -Name dryrun
 

Import-Module $PSScriptRoot\ps_modules\VstsTaskSdk\VstsTaskSdk.psm1
Import-Module $PSScriptRoot\ps_modules\VstsAzureHelpers_\VstsAzureHelpers_.psm1

Initialize-Azure

./cleanEnv.ps1 `
    -pat $pat `
    -id_def_clean $id_def_clean `
    -name_def_clean $name_def_clean `
    -project $project `
    -clean_env $clean_env `
    -test $test
