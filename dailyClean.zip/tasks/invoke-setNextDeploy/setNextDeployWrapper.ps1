[CmdletBinding(DefaultParameterSetName = 'None')]
param()

$pat = $Env:SYSTEM_ACCESSTOKEN
$id_def_clean = $Env:Release_DefinitionId
$name_def_clean = $Env:Release_DefinitionName
$project = $Env:System_TeamProject
$env_to_clean = $Env:Release_EnvironmentName
$test = Get-VstsInput -Name dryrun

Import-Module $PSScriptRoot\ps_modules\VstsTaskSdk\VstsTaskSdk.psm1

./setNextDeploy.ps1 `
    -pat $pat `
    -id_def_clean $id_def_clean `
    -name_def_clean $name_def_clean `
    -project $project `
    -env_to_clean $env_to_clean `
    -test $test
