# This script have to create and set new deployment set with last successfull for stages whose mentionne in input list.
# This script call from schedule release each day evening
#
# Input : ID clean release ; Name clean relese ; list env
#
# Output : Projet definition ID ; ID Env Def 
#
# Exemple : https://axafrance.vsrm.visualstudio.com/SelfCare/_apis/Release/deployments?definitionId=18&definitionEnvironmentId=55&deploymentStatus=30&operationStatus=7960&%24top=1

#######################
###### Arguments ######
#######################

param  
( 
  [string] $pat,
  [string] $id_def_clean,
  [string] $name_def_clean,
  [string] $project,
  [string] $env_to_clean,
  [string] $test
)

#######################
###### Variables ######
#######################
$version_api="5.1-preview"
$organization = "axafrance"
$url_api = "https://vsrm.dev.azure.com/$organization/$project/_apis"
$name_def_project = $name_def_clean.replace(" - DailyClean", "")
$last_success = @()
$result = @{}

#######################
###### Functions ######
#######################

function call_url
{
    param([string]$u)
    $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "pat", $pat)))  
    try {
        $result = (Invoke-RestMethod `
        -Uri $u `
        -Method Get `
        -ContentType "application/json" `
        -Headers @{Authorization = ("Basic {0}" -f $auth)} `
        -UseBasicParsing)
        return $result
    }
    catch {
        Write-host "StatusCode : " $_.Exception.Response.StatusCode.Value__
        Write-host "StatusDescription : " $_.Exception.Response.StatusDescription
        exit
    }
}

function get_release_info
{
  param([string]$r,[string]$e)
  $url = "$url_api/release/definitions?searchText=$($r)&isExactNameMatch=true&`$expand=environments&api-version=$version_api"
  $releasedefs_project = call_url($url)
  $result = $releasedefs_project.value | select -First 1
  $id_release_project = $result.id
  $id_env_project = $result.environments | where-object {$_.name -eq "$e"} | select-object -Property id
  $id_release_project
  $id_env_project.id
}

function get_deployment
{
    param([int32]$r,[int32]$e,[string]$n)
    $url =  "$url_api/Release/deployments?definitionId=$($r)&definitionEnvironmentId=$($e)&deploymentStatus=succeeded&operationStatus=7960&%24top=1&api-version=$version_api"
    $result = $(call_url($url)).value | select -First 1
    $id_release = $result.release.id
    $id_env = $result.releaseEnvironment | where-object {$_.Name -eq "$n"} | select-object -Property id
    $id_release
    $id_env.id
    $result.release.name
    $result.releaseEnvironment.Name
}

function patch_deployment
{
  param([int32]$r,[int32]$e)
  $url = "$url_api/Release/releases/$($r)/environments/$($e)?api-version=$version_api"
  $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "pat", $pat)))  
  try {
    $result = (Invoke-RestMethod `
    -Uri $url `
    -Method Patch `
    -Body "{'status':'2','scheduledDeploymentTime':null,'comment':'redeploy'}" `
    -ContentType "application/json" `
    -Headers @{Authorization = ("Basic {0}" -f $auth)} `
    -UseBasicParsing)
    return $result
  }
  catch {
      Write-host "StatusCode : " $_.Exception.Response.StatusCode.Value__
      Write-host "StatusDescription : " $_.Exception.Response.StatusDescription
      write-host "==> Deployment FAILED" -ForegroundColor Red
      exit 1
  }
}

function check_approval
{
    param([int32]$r, [int32]$e)
    $url =  "$url_api/Release/approvals?api-version=$version_api"
    $result = $(call_url($url)).Value
    
    foreach ($item in $result)
    {
      if ($item.release.id -eq $($r) -and $item.releaseEnvironment.id -eq $($e))
      {
        write-host "==> Release need approuvers" -ForegroundColor Yellow
        $url =  "$url_api/Release/approvals/$($item.id)?api-version=$version_api"
        $auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "pat", $pat)))  
        try {
          $result_approuvers = (Invoke-RestMethod `
          -Uri $url `
          -Method Patch `
          -Body "{'status': 'Approved','comments': 'DailyAutomation'}" `
          -ContentType "application/json" `
          -Headers @{Authorization = ("Basic {0}" -f $auth)} `
          -UseBasicParsing)
        }
        catch {
            Write-host "StatusCode : " $_.Exception.Response.StatusCode.Value__
            Write-host "StatusDescription : " $_.Exception.Response.StatusDescription
            write-host "==> Realease approuved FAILED" -ForegroundColor Red
            exit 1
        }
        write-host "==> Realease approuved by $($item.approver.displayName)" -ForegroundColor Green
      }
    }
}

function checkstart {
  param([INT32]$r, [INT32]$e)
  $url = "$url_api/release/deployments?definitionEnvironmentId=$($e)&definitionId=$($r)&DeploymentStatus=inProgress&`$top=1"
  $result = $(call_url($url)).count
  if ($result -gt 0)
    {
      return $True
      break
    }
  return $False
}

#######################
######    Main   ######
#######################
Write-Host "----------------------------------------"
Write-host "id_def_clean : $id_def_clean"
Write-host "name_def_clean : $name_def_clean"
Write-host "env_to_clean : $env_to_clean"
Write-host "-- Dry-run : $test"
Write-Host "----------------------------------------"
Write-Host "----------------------------------------"

## Get back the release project infos
$env_to_clean = $env_to_clean.Replace("Redeploy-","")

$info_release_project = get_release_info $name_def_project $env_to_clean
if ($info_release_project[1] -eq $null)
{
  write-host "The environnement $env_to_clean doesn't exist, please check the stage name from the release definition project." -ForegroundColor Red
  write-host " ==> The environnement name must be the same between the project definition and the clean definition" -ForegroundColor Yellow
  write-host " ==> Correct the clean stage name ans try again" -ForegroundColor Yellow
  exit
}
## Get back the last success infos
$last_success_deployment = get_deployment $info_release_project[0] $info_release_project[1] $env_to_clean
write-host "Find release $($last_success_deployment[2]) to redeploy in environnement $($last_success_deployment[3])" -ForegroundColor Green

# If dryrun enable, go to exit
if ($test -match "true")
{
  write-host "##################################################"
  write-host "-- Dry Run mode -> The release was not redeploy --"
  write-host "##################################################"
  exit
}

## Go redeploy the release
$redeploy = patch_deployment $last_success_deployment[0] $last_success_deployment[1]
Write-Host "==> Start deployment $($redeploy.id)"

# Check approuvers
while ( $(checkstart $info_release_project[0] $info_release_project[1]) -notlike $True )
{
  check_approval $($last_success_deployment[0]) $($last_success_deployment[1])
}
