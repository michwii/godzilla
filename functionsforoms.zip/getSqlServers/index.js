var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
        
    async.waterfall([
        commons.getAccessToken.bind(null, tenant_id, client_id, client_secret),
        getSqlServersList.bind(null, subscriptionId)//,
        //commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "SqlServers")
    ], function(err, sqlServers){
        var requestsForOMS = [];
        for(var sqlServer of sqlServers){
            if(commons.shouldIStoreThisResourceInsideMyOMS(sqlServer.resourceGroup, env))
                requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "SqlServers", sqlServer));
        }
        async.parallelLimit(requestsForOMS, 10, function(err, results){
            console.log(results);
            context.done();
        })
    });
}

var getSqlServersList = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/providers/Microsoft.Sql/servers?api-version=2014-04-01";
    commons.getDataFromMSAPI(accessToken, url, function(err, sqlServers){
        if(err) throw err;
        for(sqlServer of sqlServers){
            var subStr = sqlServer.id.match("resourceGroups/(.*)/providers/");
            sqlServer.resourceGroup = subStr[1];
        }
        callback(err, sqlServers);
    });

}
