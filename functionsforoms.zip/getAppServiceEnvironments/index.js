var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
    
    
    async.waterfall([
        commons.getAccessToken.bind(null, tenant_id, client_id, client_secret),
        getAppServiceEnvironments.bind(null, subscriptionId),
        
    ], function(err, appServiceEnvironments){
        var requestsForOMS = [];
        for(var appServiceEnvironment of appServiceEnvironments){
            if(commons.shouldIStoreThisResourceInsideMyOMS(appServiceEnvironment.resourceGroup, env))
                requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "AppServiceEnvironments", appServiceEnvironment));
        }
        async.parallelLimit(requestsForOMS, 10, function(err, results){
            console.log(results);
            context.done();
        })
    });
    
};

var getAppServiceEnvironments = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/providers/Microsoft.Web/hostingEnvironments?api-version=2016-09-01";
    commons.getDataFromMSAPI(accessToken, url, function(err, appServiceEnvironments){
        for(appServiceEnvironment of appServiceEnvironments){
            var subStr = appServiceEnvironment.id.match("resourceGroups/(.*)/providers/");
            appServiceEnvironment.resourceGroup = subStr[1];
        }
        callback(err, appServiceEnvironments);
    });
}