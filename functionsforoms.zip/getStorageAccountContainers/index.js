var request = require('request');
var async = require('async');
var commons = require("../shared/commons");
var console = {};

var workspaceId = process.env.WORKSPACE_ID;
var sharedKey = process.env.SHARED_KEY;
var subscriptionId = process.env.SUBSCRIPTION_ID ;
var tenant_id = process.env.TENANT_ID;
var client_id = process.env.CLIENT_ID;
var client_secret = process.env.CLIENT_SECRET;
var env = process.env.ENVIRONMENT;

module.exports = function (context, myTimer) {
    console = context;
    var timeStamp = new Date().toISOString();
    
    if(myTimer.isPastDue)
    {
        context.log('JavaScript is running late!');
    }
    commons.getAccessToken(tenant_id, client_id, client_secret, function(err, accessToken){
        if(err) throw err;
        getStorageAccountList(subscriptionId, accessToken, function(err, storageAccounts){
            if(err) throw err;
            async.mapLimit(storageAccounts, 10, getContainersByStorageAccount.bind(null, subscriptionId, accessToken), function(err, storageAccounts){
                if(err) throw err;
                var requestsForOMS = [];
                for(var storageAccount of storageAccounts){
                    for(var container of storageAccount){
                        if(commons.shouldIStoreThisResourceInsideMyOMS(container.resourceGroup, env))
                            requestsForOMS.push(commons.sendDataToOMS.bind(null, workspaceId, sharedKey, "StorageAccountContainers", container));
                    }
                }
                
                async.parallelLimit(requestsForOMS, 10, function(err, results){
                    console.log(results);
                    context.done();
                })
            });   
        });
    });
}

var getStorageAccountList = function(subscriptionId, accessToken, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/providers/Microsoft.Storage/storageAccounts?api-version=2018-03-01-preview";
    commons.getDataFromMSAPI(accessToken, url, function(err, storageAccounts){
        if(err) throw err;
        for(storageAccount of storageAccounts){
            var subStr = storageAccount.id.match("resourceGroups/(.*)/providers/");
            storageAccount.resourceGroup = subStr[1];
        }
        callback(err, storageAccounts);
    });
}

var getContainersByStorageAccount = function(subscriptionId, accessToken, storageAccount, callback){
    var url = "https://management.azure.com/subscriptions/"+subscriptionId+"/resourceGroups/"+storageAccount.resourceGroup+"/providers/Microsoft.Storage/storageAccounts/"+storageAccount.name+"/blobServices/default/containers?api-version=2018-03-01-preview"

    commons.getDataFromMSAPI(accessToken, url, function(err, containers){
        if(err) throw err;
        for(var container of containers){
            container.storageAccount = storageAccount.name;
            var subStr = container.id.match("resourceGroups/(.*)/providers/");
            container.resourceGroup = subStr[1];
        }
        callback(err, containers);
    });
};